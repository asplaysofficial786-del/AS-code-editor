import { create } from 'zustand';

export interface EditorState {
  code: string;
  language: string;
  theme: string;
  cursorPosition: { line: number; column: number };
  isDirty: boolean;
  aiSuggestion: string;
  isAiLoading: boolean;
  fontSize: number;
  tabSize: number;
  lineNumbers: boolean;
  wordWrap: boolean;

  setCode: (code: string) => void;
  setLanguage: (language: string) => void;
  setTheme: (theme: string) => void;
  setCursorPosition: (pos: { line: number; column: number }) => void;
  setDirty: (dirty: boolean) => void;
  setAiSuggestion: (suggestion: string) => void;
  setAiLoading: (loading: boolean) => void;
  clearAiSuggestion: () => void;
  setFontSize: (size: number) => void;
  setTabSize: (size: number) => void;
  setLineNumbers: (enabled: boolean) => void;
  setWordWrap: (enabled: boolean) => void;
}

export const useEditorStore = create<EditorState>((set) => ({
  code: '// Welcome to AS Code\n// Start typing or open a file\n\nconsole.log("Hello, World!");\n',
  language: 'javascript',
  theme: 'githubDarkPro',
  cursorPosition: { line: 1, column: 1 },
  isDirty: false,
  aiSuggestion: '',
  isAiLoading: false,
  fontSize: 14,
  tabSize: 2,
  lineNumbers: true,
  wordWrap: false,

  setCode: (code) => set({ code, isDirty: true }),
  setLanguage: (language) => set({ language }),
  setTheme: (theme) => set({ theme }),
  setCursorPosition: (cursorPosition) => set({ cursorPosition }),
  setDirty: (isDirty) => set({ isDirty }),
  setAiSuggestion: (aiSuggestion) => set({ aiSuggestion }),
  setAiLoading: (isAiLoading) => set({ isAiLoading }),
  clearAiSuggestion: () => set({ aiSuggestion: '', isAiLoading: false }),
  setFontSize: (fontSize) => set({ fontSize }),
  setTabSize: (tabSize) => set({ tabSize }),
  setLineNumbers: (lineNumbers) => set({ lineNumbers }),
  setWordWrap: (wordWrap) => set({ wordWrap }),
}));
