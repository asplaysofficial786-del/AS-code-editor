import { create } from 'zustand';
import { PISTON_MODE, PISTON_URLS } from '../config/pistonConfig';

export interface SettingsState {
  // Editor prefs
  fontSize: number;
  tabSize: number;
  lineNumbers: boolean;
  wordWrap: boolean;
  autoSave: boolean;
  autoCloseBrackets: boolean;
  autoCloseQuotes: boolean;

  // AI prefs
  aiAutocompleteEnabled: boolean;
  aiTriggerMode: 'as-you-type' | 'manual';

  // Preview prefs
  previewAutoRefresh: boolean;
  previewLayout: 'split' | 'fullscreen';

  // Piston prefs
  pistonMode: 'public' | 'self-hosted';
  pistonSelfHostedUrl: string;

  // Theme
  activeTheme: string;

  // Docs
  downloadDocsOnWifiOnly: boolean;

  setFontSize: (size: number) => void;
  setTabSize: (size: number) => void;
  setLineNumbers: (enabled: boolean) => void;
  setWordWrap: (enabled: boolean) => void;
  setAutoSave: (enabled: boolean) => void;
  setAutoCloseBrackets: (enabled: boolean) => void;
  setAutoCloseQuotes: (enabled: boolean) => void;
  setAiAutocompleteEnabled: (enabled: boolean) => void;
  setAiTriggerMode: (mode: 'as-you-type' | 'manual') => void;
  setPreviewAutoRefresh: (enabled: boolean) => void;
  setPreviewLayout: (layout: 'split' | 'fullscreen') => void;
  setPistonMode: (mode: 'public' | 'self-hosted') => void;
  setPistonSelfHostedUrl: (url: string) => void;
  setActiveTheme: (theme: string) => void;
  setDownloadDocsOnWifiOnly: (enabled: boolean) => void;
}

export const useSettingsStore = create<SettingsState>((set) => ({
  fontSize: 14,
  tabSize: 2,
  lineNumbers: true,
  wordWrap: false,
  autoSave: true,
  autoCloseBrackets: true,
  autoCloseQuotes: true,

  aiAutocompleteEnabled: true,
  aiTriggerMode: 'as-you-type',

  previewAutoRefresh: true,
  previewLayout: 'split',

  pistonMode: PISTON_MODE,
  pistonSelfHostedUrl: PISTON_URLS.selfHosted,

  activeTheme: 'githubDarkPro',

  downloadDocsOnWifiOnly: true,

  setFontSize: (fontSize) => set({ fontSize }),
  setTabSize: (tabSize) => set({ tabSize }),
  setLineNumbers: (lineNumbers) => set({ lineNumbers }),
  setWordWrap: (wordWrap) => set({ wordWrap }),
  setAutoSave: (autoSave) => set({ autoSave }),
  setAutoCloseBrackets: (autoCloseBrackets) => set({ autoCloseBrackets }),
  setAutoCloseQuotes: (autoCloseQuotes) => set({ autoCloseQuotes }),
  setAiAutocompleteEnabled: (aiAutocompleteEnabled) =>
    set({ aiAutocompleteEnabled }),
  setAiTriggerMode: (aiTriggerMode) => set({ aiTriggerMode }),
  setPreviewAutoRefresh: (previewAutoRefresh) => set({ previewAutoRefresh }),
  setPreviewLayout: (previewLayout) => set({ previewLayout }),
  setPistonMode: (pistonMode) => set({ pistonMode }),
  setPistonSelfHostedUrl: (pistonSelfHostedUrl) =>
    set({ pistonSelfHostedUrl }),
  setActiveTheme: (activeTheme) => set({ activeTheme }),
  setDownloadDocsOnWifiOnly: (downloadDocsOnWifiOnly) =>
    set({ downloadDocsOnWifiOnly }),
}));
