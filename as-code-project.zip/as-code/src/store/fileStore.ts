import { create } from 'zustand';

export interface FileTab {
  id: string;
  name: string;
  path: string;
  language: string;
  content: string;
  isDirty: boolean;
  isUnsaved: boolean;
}

export interface FileNode {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'folder';
  language?: string;
  children?: FileNode[];
  isExpanded?: boolean;
}

export interface FileState {
  openTabs: FileTab[];
  activeTabId: string | null;
  currentProjectName: string;
  currentProjectPath: string;
  fileTree: FileNode[];
  projects: string[];

  openFile: (file: Omit<FileTab, 'id' | 'isDirty' | 'isUnsaved'>) => void;
  closeTab: (tabId: string) => void;
  setActiveTab: (tabId: string) => void;
  updateTabContent: (tabId: string, content: string) => void;
  markTabSaved: (tabId: string) => void;
  setFileTree: (tree: FileNode[]) => void;
  toggleFolder: (nodeId: string) => void;
  setCurrentProject: (name: string, path: string) => void;
  setProjects: (projects: string[]) => void;
}

export const useFileStore = create<FileState>((set, get) => ({
  openTabs: [],
  activeTabId: null,
  currentProjectName: 'Untitled Project',
  currentProjectPath: '',
  fileTree: [],
  projects: [],

  openFile: (file) => {
    const { openTabs } = get();
    const MAX_TABS = 10;

    // If already open, just activate it
    const existing = openTabs.find((t) => t.path === file.path);
    if (existing) {
      set({ activeTabId: existing.id });
      return;
    }

    // Enforce max tab limit
    if (openTabs.length >= MAX_TABS) {
      // Close first non-dirty tab
      const closeable = openTabs.find((t) => !t.isDirty);
      if (closeable) {
        set((state) => ({
          openTabs: state.openTabs.filter((t) => t.id !== closeable.id),
        }));
      } else {
        return; // All tabs are dirty, can't open more
      }
    }

    const newTab: FileTab = {
      ...file,
      id: `tab-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      isDirty: false,
      isUnsaved: false,
    };

    set((state) => ({
      openTabs: [...state.openTabs, newTab],
      activeTabId: newTab.id,
    }));
  },

  closeTab: (tabId) => {
    const { openTabs, activeTabId } = get();
    const idx = openTabs.findIndex((t) => t.id === tabId);
    const newTabs = openTabs.filter((t) => t.id !== tabId);

    let newActiveId: string | null = null;
    if (activeTabId === tabId && newTabs.length > 0) {
      newActiveId = newTabs[Math.max(0, idx - 1)].id;
    } else if (activeTabId !== tabId) {
      newActiveId = activeTabId;
    }

    set({ openTabs: newTabs, activeTabId: newActiveId });
  },

  setActiveTab: (tabId) => set({ activeTabId: tabId }),

  updateTabContent: (tabId, content) => {
    set((state) => ({
      openTabs: state.openTabs.map((t) =>
        t.id === tabId ? { ...t, content, isDirty: true } : t
      ),
    }));
  },

  markTabSaved: (tabId) => {
    set((state) => ({
      openTabs: state.openTabs.map((t) =>
        t.id === tabId ? { ...t, isDirty: false, isUnsaved: false } : t
      ),
    }));
  },

  setFileTree: (fileTree) => set({ fileTree }),

  toggleFolder: (nodeId) => {
    const toggle = (nodes: FileNode[]): FileNode[] =>
      nodes.map((n) => {
        if (n.id === nodeId) return { ...n, isExpanded: !n.isExpanded };
        if (n.children) return { ...n, children: toggle(n.children) };
        return n;
      });
    set((state) => ({ fileTree: toggle(state.fileTree) }));
  },

  setCurrentProject: (name, path) =>
    set({ currentProjectName: name, currentProjectPath: path }),

  setProjects: (projects) => set({ projects }),
}));
