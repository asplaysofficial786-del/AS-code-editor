import { create } from 'zustand';

export interface Extension {
  id: string;
  name: string;
  description: string;
  version: string;
  isInstalled: boolean;
  isActive: boolean;
  icon: string;
  category: 'theme' | 'tool' | 'language' | 'snippet';
}

export interface ExtensionState {
  extensions: Extension[];
  toggleExtension: (id: string) => void;
  activateExtension: (id: string) => void;
  deactivateExtension: (id: string) => void;
}

const DEFAULT_EXTENSIONS: Extension[] = [
  {
    id: 'themes',
    name: 'Theme Pack',
    description: '10 premium editor themes including GitHub Dark Pro, Dracula, One Dark, and more.',
    version: '1.0.0',
    isInstalled: true,
    isActive: true,
    icon: '🎨',
    category: 'theme',
  },
  {
    id: 'git',
    name: 'Git Integration',
    description: 'Full Git support: clone, push, pull, commit, diff — powered by isomorphic-git.',
    version: '1.0.0',
    isInstalled: true,
    isActive: true,
    icon: '🌿',
    category: 'tool',
  },
  {
    id: 'prettier',
    name: 'Prettier Formatter',
    description: 'Auto-format your code with Prettier — supports JS, TS, HTML, CSS, JSON, and more.',
    version: '1.0.0',
    isInstalled: true,
    isActive: true,
    icon: '✨',
    category: 'tool',
  },
  {
    id: 'snippets',
    name: 'Snippet Library',
    description: 'Pre-built and custom snippets for all supported languages. VS Code compatible import.',
    version: '1.0.0',
    isInstalled: true,
    isActive: true,
    icon: '📦',
    category: 'snippet',
  },
];

export const useExtensionStore = create<ExtensionState>((set) => ({
  extensions: DEFAULT_EXTENSIONS,

  toggleExtension: (id) =>
    set((state) => ({
      extensions: state.extensions.map((ext) =>
        ext.id === id ? { ...ext, isActive: !ext.isActive } : ext
      ),
    })),

  activateExtension: (id) =>
    set((state) => ({
      extensions: state.extensions.map((ext) =>
        ext.id === id ? { ...ext, isActive: true } : ext
      ),
    })),

  deactivateExtension: (id) =>
    set((state) => ({
      extensions: state.extensions.map((ext) =>
        ext.id === id ? { ...ext, isActive: false } : ext
      ),
    })),
}));
