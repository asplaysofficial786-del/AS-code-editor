import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
  SafeAreaView,
} from 'react-native';
import { useExtensionStore } from '../store/extensionStore';
import { useTheme } from '../hooks/useTheme';
import ThemePicker from '../components/extensions/ThemePicker';

type ExtensionView = 'list' | 'themes';

export default function ExtensionsScreen() {
  const theme = useTheme();
  const { extensions, toggleExtension } = useExtensionStore();
  const [view, setView] = useState<ExtensionView>('list');

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: theme.colors.background }]}
    >
      {/* Header */}
      <View
        style={[
          styles.header,
          { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: theme.colors.text }]}>
          Extensions
        </Text>
        <View style={[styles.segmented, { backgroundColor: theme.colors.overlay }]}>
          {(['list', 'themes'] as ExtensionView[]).map((v) => (
            <TouchableOpacity
              key={v}
              onPress={() => setView(v)}
              style={[
                styles.segment,
                view === v && { backgroundColor: theme.colors.accent },
              ]}
            >
              <Text
                style={[
                  styles.segmentText,
                  { color: view === v ? '#fff' : theme.colors.muted },
                ]}
              >
                {v === 'list' ? '🔌 All' : '🎨 Themes'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {view === 'themes' ? (
        <ThemePicker />
      ) : (
        <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
          {extensions.map((ext) => (
            <View
              key={ext.id}
              style={[
                styles.card,
                { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
              ]}
            >
              <View style={styles.cardLeft}>
                <View
                  style={[
                    styles.iconContainer,
                    { backgroundColor: theme.colors.overlay },
                  ]}
                >
                  <Text style={styles.extIcon}>{ext.icon}</Text>
                </View>
                <View style={styles.cardInfo}>
                  <View style={styles.nameRow}>
                    <Text style={[styles.extName, { color: theme.colors.text }]}>
                      {ext.name}
                    </Text>
                    <View
                      style={[styles.versionBadge, { backgroundColor: theme.colors.overlay }]}
                    >
                      <Text style={[styles.version, { color: theme.colors.muted }]}>
                        v{ext.version}
                      </Text>
                    </View>
                  </View>
                  <Text
                    style={[styles.extDesc, { color: theme.colors.muted }]}
                    numberOfLines={2}
                  >
                    {ext.description}
                  </Text>
                </View>
              </View>
              <Switch
                value={ext.isActive}
                onValueChange={() => toggleExtension(ext.id)}
                trackColor={{
                  false: theme.colors.border,
                  true: theme.colors.accent + '66',
                }}
                thumbColor={ext.isActive ? theme.colors.accent : theme.colors.muted}
              />
            </View>
          ))}

          {/* Coming soon */}
          <View
            style={[
              styles.comingSoonCard,
              { backgroundColor: theme.colors.surface, borderColor: '#d29922' + '44' },
            ]}
          >
            <View style={styles.comingSoonHeader}>
              <View style={[styles.warnBadge, { backgroundColor: '#d2992222' }]}>
                <Text style={styles.warnText}>🚧 COMING SOON</Text>
              </View>
            </View>
            <Text style={[styles.comingSoonTitle, { color: theme.colors.text }]}>
              AS Lang Extension
            </Text>
            <Text style={[styles.comingSoonDesc, { color: theme.colors.muted }]}>
              Native support for AS Lang — Anthropic's custom scripting language
              designed for AI-first mobile coding. Run AS Lang code directly in
              AS Code without any external dependencies.
            </Text>
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    gap: 12,
  },
  headerTitle: { fontSize: 20, fontWeight: '700' },
  segmented: {
    flexDirection: 'row',
    borderRadius: 8,
    padding: 3,
    gap: 2,
  },
  segment: {
    flex: 1,
    paddingVertical: 6,
    borderRadius: 6,
    alignItems: 'center',
  },
  segmentText: { fontSize: 12, fontWeight: '600' },
  scroll: { flex: 1 },
  content: { padding: 12, gap: 10 },
  card: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardLeft: {
    flex: 1,
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  extIcon: { fontSize: 22 },
  cardInfo: { flex: 1, gap: 4 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  extName: { fontSize: 15, fontWeight: '600' },
  versionBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  version: { fontSize: 10 },
  extDesc: { fontSize: 12, lineHeight: 17 },
  comingSoonCard: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    gap: 8,
    marginTop: 4,
  },
  comingSoonHeader: { flexDirection: 'row' },
  warnBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  warnText: { color: '#d29922', fontSize: 11, fontWeight: '700', letterSpacing: 0.5 },
  comingSoonTitle: { fontSize: 16, fontWeight: '700' },
  comingSoonDesc: { fontSize: 13, lineHeight: 19 },
});
