import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity,
  TextInput, StyleSheet, SafeAreaView, Modal,
} from 'react-native';
import { useTheme } from '../hooks/useTheme';
import { storageGet, storageSet, STORAGE_KEYS } from '../utils/storage';
import SearchBar from '../components/common/SearchBar';
import ToastMessage, { ToastType } from '../components/common/ToastMessage';

interface Snippet {
  id: string;
  name: string;
  prefix: string;
  body: string;
  description: string;
  language: string;
}

const BUILTIN_SNIPPETS: Snippet[] = [
  { id: 'js-log',   language: 'javascript', name: 'Console Log',     prefix: 'log',   body: 'console.log($1);',                               description: 'console.log statement' },
  { id: 'js-arrow', language: 'javascript', name: 'Arrow Function',  prefix: 'arfn',  body: 'const $1 = ($2) => {\n  $3\n};',               description: 'Arrow function' },
  { id: 'js-async', language: 'javascript', name: 'Async Function',  prefix: 'asfn',  body: 'async function $1($2) {\n  try {\n    $3\n  } catch (err) {\n    console.error(err);\n  }\n}', description: 'Async/await function' },
  { id: 'py-def',   language: 'python',     name: 'Function',        prefix: 'def',   body: 'def $1($2):\n    """$3"""\n    $4',              description: 'Python function with docstring' },
  { id: 'py-class', language: 'python',     name: 'Class',           prefix: 'class', body: 'class $1:\n    def __init__(self):\n        $2',  description: 'Python class' },
  { id: 'html-doc', language: 'html',       name: 'HTML5 Document',  prefix: 'html5', body: '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>$1</title>\n</head>\n<body>\n  $2\n</body>\n</html>', description: 'HTML5 boilerplate' },
  { id: 'css-flex', language: 'css',        name: 'Flexbox Center',  prefix: 'flex',  body: 'display: flex;\nalign-items: center;\njustify-content: center;', description: 'Flexbox centered layout' },
  { id: 'ts-iface', language: 'typescript', name: 'Interface',       prefix: 'iface', body: 'interface $1 {\n  $2: $3;\n}',                   description: 'TypeScript interface' },
];

export default function SnippetsScreen() {
  const theme = useTheme();
  const [snippets, setSnippets]   = useState<Snippet[]>(BUILTIN_SNIPPETS);
  const [query, setQuery]         = useState('');
  const [langFilter, setLangFilter] = useState('all');
  const [showAdd, setShowAdd]     = useState(false);
  const [editing, setEditing]     = useState<Snippet | null>(null);
  const [toast, setToast]         = useState<{ message: string; type: ToastType } | null>(null);

  useEffect(() => {
    storageGet<Snippet[]>(STORAGE_KEYS.USER_SNIPPETS).then(saved => {
      if (saved) setSnippets([...BUILTIN_SNIPPETS, ...saved]);
    });
  }, []);

  const saveUserSnippets = async (all: Snippet[]) => {
    const user = all.filter(s => !BUILTIN_SNIPPETS.find(b => b.id === s.id));
    await storageSet(STORAGE_KEYS.USER_SNIPPETS, user);
  };

  const langs = ['all', ...Array.from(new Set(snippets.map(s => s.language)))];

  const filtered = snippets.filter(s => {
    const matchLang = langFilter === 'all' || s.language === langFilter;
    const matchQ = !query || s.name.toLowerCase().includes(query.toLowerCase()) || s.prefix.toLowerCase().includes(query.toLowerCase());
    return matchLang && matchQ;
  });

  const handleSave = async (snippet: Omit<Snippet, 'id'> & { id?: string }) => {
    const id = snippet.id ?? `user-${Date.now()}`;
    const updated = snippet.id
      ? snippets.map(s => s.id === snippet.id ? { ...snippet, id } : s)
      : [...snippets, { ...snippet, id }];
    setSnippets(updated);
    await saveUserSnippets(updated);
    setShowAdd(false);
    setEditing(null);
    setToast({ message: snippet.id ? 'Snippet updated' : 'Snippet saved', type: 'success' });
  };

  const handleDelete = async (id: string) => {
    const updated = snippets.filter(s => s.id !== id);
    setSnippets(updated);
    await saveUserSnippets(updated);
    setToast({ message: 'Snippet deleted', type: 'info' });
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={[styles.header, { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border }]}>
        <Text style={[styles.title, { color: theme.colors.text }]}>Snippets</Text>
        <TouchableOpacity onPress={() => setShowAdd(true)} style={[styles.addBtn, { backgroundColor: theme.colors.accent }]}>
          <Text style={styles.addBtnText}>+ New</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.filters}>
        <SearchBar value={query} onChangeText={setQuery} placeholder="Search snippets..." />
      </View>

      {/* Language filter */}
      <FlatList
        horizontal
        data={langs}
        keyExtractor={l => l}
        showsHorizontalScrollIndicator={false}
        style={styles.langList}
        contentContainerStyle={{ paddingHorizontal: 10, gap: 6 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => setLangFilter(item)}
            style={[styles.langChip, { backgroundColor: langFilter === item ? theme.colors.accent : theme.colors.overlay }]}
          >
            <Text style={[styles.langChipText, { color: langFilter === item ? '#fff' : theme.colors.muted }]}>{item}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Snippet list */}
      <FlatList
        data={filtered}
        keyExtractor={s => s.id}
        contentContainerStyle={{ padding: 10, gap: 8 }}
        renderItem={({ item }) => (
          <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
            <View style={styles.cardHeader}>
              <View style={[styles.prefixBadge, { backgroundColor: theme.colors.overlay }]}>
                <Text style={[styles.prefix, { color: theme.colors.accent, fontFamily: 'JetBrainsMono-Regular' }]}>{item.prefix}</Text>
              </View>
              <Text style={[styles.snippetName, { color: theme.colors.text }]}>{item.name}</Text>
              <View style={[styles.langTag, { backgroundColor: theme.colors.overlay }]}>
                <Text style={[styles.langTagText, { color: theme.colors.muted }]}>{item.language}</Text>
              </View>
            </View>
            {item.description && (
              <Text style={[styles.desc, { color: theme.colors.muted }]}>{item.description}</Text>
            )}
            <View style={[styles.codePreview, { backgroundColor: theme.colors.terminal }]}>
              <Text style={[styles.code, { color: theme.colors.text, fontFamily: 'JetBrainsMono-Regular' }]} numberOfLines={3}>
                {item.body.replace(/\$\d/g, '█')}
              </Text>
            </View>
            {!BUILTIN_SNIPPETS.find(b => b.id === item.id) && (
              <View style={styles.actions}>
                <TouchableOpacity onPress={() => { setEditing(item); setShowAdd(true); }}>
                  <Text style={[styles.actionText, { color: theme.colors.accent }]}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => handleDelete(item.id)}>
                  <Text style={[styles.actionText, { color: theme.colors.error }]}>Delete</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
      />

      {/* Add/Edit modal */}
      <SnippetModal
        visible={showAdd}
        initial={editing}
        theme={theme}
        onClose={() => { setShowAdd(false); setEditing(null); }}
        onSave={handleSave}
      />
      {toast && <ToastMessage message={toast.message} type={toast.type} visible onHide={() => setToast(null)} />}
    </SafeAreaView>
  );
}

function SnippetModal({ visible, initial, theme, onClose, onSave }: any) {
  const [name, setName]     = useState(initial?.name ?? '');
  const [prefix, setPrefix] = useState(initial?.prefix ?? '');
  const [body, setBody]     = useState(initial?.body ?? '');
  const [desc, setDesc]     = useState(initial?.description ?? '');
  const [lang, setLang]     = useState(initial?.language ?? 'javascript');

  useEffect(() => {
    if (initial) { setName(initial.name); setPrefix(initial.prefix); setBody(initial.body); setDesc(initial.description); setLang(initial.language); }
    else { setName(''); setPrefix(''); setBody(''); setDesc(''); setLang('javascript'); }
  }, [initial, visible]);

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: '#00000088', justifyContent: 'flex-end' }}>
        <View style={[{ backgroundColor: theme.colors.surface, borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: 20, gap: 12 }]}>
          <Text style={[{ color: theme.colors.text, fontSize: 16, fontWeight: '700' }]}>
            {initial ? 'Edit Snippet' : 'New Snippet'}
          </Text>
          {[
            { label: 'Name', value: name, set: setName },
            { label: 'Prefix (trigger)', value: prefix, set: setPrefix },
            { label: 'Language', value: lang, set: setLang },
            { label: 'Description', value: desc, set: setDesc },
          ].map(f => (
            <TextInput key={f.label} style={[{ color: theme.colors.text, backgroundColor: theme.colors.overlay, borderRadius: 8, padding: 10, borderWidth: 1, borderColor: theme.colors.border }]}
              value={f.value} onChangeText={f.set} placeholder={f.label} placeholderTextColor={theme.colors.muted} autoCapitalize="none" />
          ))}
          <TextInput
            style={[{ color: theme.colors.text, backgroundColor: theme.colors.terminal, borderRadius: 8, padding: 10, fontFamily: 'JetBrainsMono-Regular', fontSize: 12, minHeight: 80, textAlignVertical: 'top', borderWidth: 1, borderColor: theme.colors.border }]}
            value={body} onChangeText={setBody} placeholder="Snippet body — use $1, $2 for tab stops" placeholderTextColor={theme.colors.muted} multiline autoCapitalize="none" autoCorrect={false}
          />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <TouchableOpacity onPress={onClose} style={[{ flex: 1, padding: 12, borderRadius: 8, backgroundColor: theme.colors.overlay, alignItems: 'center' }]}>
              <Text style={{ color: theme.colors.muted, fontWeight: '600' }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => onSave({ id: initial?.id, name, prefix, body, description: desc, language: lang })}
              disabled={!name.trim() || !body.trim()}
              style={[{ flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#1a3a58', alignItems: 'center', opacity: (!name.trim() || !body.trim()) ? 0.4 : 1 }]}
            >
              <Text style={{ color: theme.colors.accent, fontWeight: '700' }}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container:   { flex: 1 },
  header:      { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1 },
  title:       { fontSize: 20, fontWeight: '700', flex: 1 },
  addBtn:      { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 8 },
  addBtnText:  { color: '#fff', fontWeight: '700', fontSize: 13 },
  filters:     { padding: 10 },
  langList:    { maxHeight: 40, marginBottom: 4 },
  langChip:    { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16 },
  langChipText:{ fontSize: 11, fontWeight: '600' },
  card:        { borderRadius: 10, borderWidth: 1, padding: 12, gap: 8 },
  cardHeader:  { flexDirection: 'row', alignItems: 'center', gap: 8 },
  prefixBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  prefix:      { fontSize: 12, fontWeight: '700' },
  snippetName: { flex: 1, fontSize: 13, fontWeight: '600' },
  langTag:     { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  langTagText: { fontSize: 10 },
  desc:        { fontSize: 11 },
  codePreview: { borderRadius: 6, padding: 8 },
  code:        { fontSize: 11, lineHeight: 16 },
  actions:     { flexDirection: 'row', gap: 16 },
  actionText:  { fontSize: 12, fontWeight: '600' },
});
