import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  TextInput,
  Modal,
  SafeAreaView,
} from 'react-native';
import { useFileStore } from '../store/fileStore';
import { useTheme } from '../hooks/useTheme';
import { useFileSystem } from '../hooks/useFileSystem';
import FileTree from '../components/explorer/FileTree';
import NewFileModal from '../components/explorer/NewFileModal';
import ToastMessage, { ToastType } from '../components/common/ToastMessage';
import { FileNode } from '../store/fileStore';
import * as FileSystem from 'expo-file-system';
import { buildFileTree } from '../services/fileSystemService';

const PROJECTS_DIR = FileSystem.documentDirectory + 'projects/';

export default function ExplorerScreen() {
  const theme = useTheme();
  const {
    fileTree,
    currentProjectName,
    currentProjectPath,
    projects,
    setFileTree,
    toggleFolder,
  } = useFileStore();

  const {
    openFileInEditor,
    refreshProjects,
    newProject,
    removeProject,
    createFile,
    createFolder,
    deleteFile,
    renameFile,
  } = useFileSystem();

  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [contextNode, setContextNode] = useState<FileNode | null>(null);
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: ToastType } | null>(null);
  const [showProjectList, setShowProjectList] = useState(false);

  useEffect(() => {
    refreshProjects();
  }, [refreshProjects]);

  const showToast = useCallback((message: string, type: ToastType = 'info') => {
    setToast({ message, type });
  }, []);

  const handleFilePress = useCallback(
    (node: FileNode) => {
      if (node.type === 'file') {
        openFileInEditor(node.path, node.name);
      }
    },
    [openFileInEditor]
  );

  const handleFileLongPress = useCallback((node: FileNode) => {
    setContextNode(node);
    setShowContextMenu(true);
  }, []);

  const handleCreateNew = useCallback(
    async (name: string, type: 'file' | 'folder') => {
      try {
        if (type === 'file') {
          await createFile(currentProjectPath, name);
        } else {
          await createFolder(currentProjectPath, name);
        }
        // Refresh tree
        const tree = await buildFileTree(currentProjectPath);
        setFileTree(tree);
        showToast(`Created ${name}`, 'success');
      } catch {
        showToast('Failed to create item', 'error');
      }
    },
    [currentProjectPath, createFile, createFolder, setFileTree, showToast]
  );

  const handleDelete = useCallback(async () => {
    if (!contextNode) return;
    setShowContextMenu(false);
    Alert.alert(
      'Delete',
      `Delete "${contextNode.name}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteFile(contextNode.path);
              const tree = await buildFileTree(currentProjectPath);
              setFileTree(tree);
              showToast(`Deleted ${contextNode.name}`, 'success');
            } catch {
              showToast('Failed to delete', 'error');
            }
          },
        },
      ]
    );
  }, [contextNode, currentProjectPath, deleteFile, setFileTree, showToast]);

  const handleNewProject = useCallback(async () => {
    const name = newProjectName.trim();
    if (!name) return;
    try {
      await newProject(name);
      setShowNewProjectModal(false);
      setNewProjectName('');
      showToast(`Project "${name}" created`, 'success');
    } catch {
      showToast('Failed to create project', 'error');
    }
  }, [newProjectName, newProject, showToast]);

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: theme.colors.background }]}
    >
      {/* Header */}
      <View
        style={[
          styles.header,
          { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
        ]}
      >
        <TouchableOpacity
          onPress={() => setShowProjectList((v) => !v)}
          style={styles.projectSelector}
        >
          <Text style={[styles.projectName, { color: theme.colors.text }]}>
            📁 {currentProjectName || 'No Project'}
          </Text>
          <Text style={[styles.chevron, { color: theme.colors.muted }]}>▾</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => setShowNewFileModal(true)}
          style={[styles.addBtn, { backgroundColor: theme.colors.accent }]}
        >
          <Text style={styles.addBtnText}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Project list dropdown */}
      {showProjectList && (
        <View
          style={[
            styles.projectList,
            { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
          ]}
        >
          <TouchableOpacity
            onPress={() => {
              setShowProjectList(false);
              setShowNewProjectModal(true);
            }}
            style={styles.newProjectRow}
          >
            <Text style={[styles.newProjectText, { color: theme.colors.accent }]}>
              + New Project
            </Text>
          </TouchableOpacity>
          {projects.map((p) => (
            <TouchableOpacity
              key={p}
              onPress={async () => {
                const { loadProject } = useFileSystem();
                // Just rebuild tree from this project
                const path = PROJECTS_DIR + p + '/';
                const tree = await buildFileTree(path);
                setFileTree(tree);
                setShowProjectList(false);
              }}
              style={[
                styles.projectRow,
                { borderTopColor: theme.colors.border },
                p === currentProjectName && { backgroundColor: theme.colors.overlay },
              ]}
            >
              <Text style={[styles.projectRowText, { color: theme.colors.text }]}>
                {p}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* File tree */}
      <ScrollView style={styles.tree} contentContainerStyle={styles.treeContent}>
        {fileTree.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>📂</Text>
            <Text style={[styles.emptyTitle, { color: theme.colors.text }]}>
              No project open
            </Text>
            <Text style={[styles.emptySubtitle, { color: theme.colors.muted }]}>
              Create a new project to get started
            </Text>
            <TouchableOpacity
              onPress={() => setShowNewProjectModal(true)}
              style={[styles.ctaButton, { backgroundColor: theme.colors.accent }]}
            >
              <Text style={styles.ctaButtonText}>Create Project</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <FileTree
            nodes={fileTree}
            onFilePress={handleFilePress}
            onFileLongPress={handleFileLongPress}
            onToggleFolder={toggleFolder}
          />
        )}
      </ScrollView>

      {/* New file/folder modal */}
      <NewFileModal
        visible={showNewFileModal}
        onClose={() => setShowNewFileModal(false)}
        onCreate={handleCreateNew}
      />

      {/* New project modal */}
      <Modal
        visible={showNewProjectModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowNewProjectModal(false)}
      >
        <View style={styles.modalBackdrop}>
          <View
            style={[
              styles.modalCard,
              { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
            ]}
          >
            <Text style={[styles.modalTitle, { color: theme.colors.text }]}>
              New Project
            </Text>
            <TextInput
              style={[
                styles.modalInput,
                {
                  color: theme.colors.text,
                  backgroundColor: theme.colors.overlay,
                  borderColor: theme.colors.border,
                  fontFamily: 'JetBrainsMono-Regular',
                },
              ]}
              value={newProjectName}
              onChangeText={setNewProjectName}
              placeholder="my-project"
              placeholderTextColor={theme.colors.muted}
              autoFocus
              autoCapitalize="none"
              onSubmitEditing={handleNewProject}
            />
            <View style={styles.modalActions}>
              <TouchableOpacity
                onPress={() => setShowNewProjectModal(false)}
                style={[styles.modalBtn, { backgroundColor: theme.colors.overlay }]}
              >
                <Text style={[styles.modalBtnText, { color: theme.colors.muted }]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleNewProject}
                style={[styles.modalBtn, { backgroundColor: '#1a3a58' }]}
              >
                <Text style={[styles.modalBtnText, { color: theme.colors.accent }]}>
                  Create
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Context menu */}
      {showContextMenu && contextNode && (
        <Modal transparent animationType="fade" onRequestClose={() => setShowContextMenu(false)}>
          <TouchableOpacity
            style={styles.contextBackdrop}
            activeOpacity={1}
            onPress={() => setShowContextMenu(false)}
          />
          <View
            style={[
              styles.contextMenu,
              { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
            ]}
          >
            <Text style={[styles.contextTitle, { color: theme.colors.muted }]}>
              {contextNode.name}
            </Text>
            {[
              { label: '🗑 Delete', action: handleDelete, color: theme.colors.error },
            ].map((item) => (
              <TouchableOpacity
                key={item.label}
                onPress={item.action}
                style={[styles.contextItem, { borderTopColor: theme.colors.border }]}
              >
                <Text style={[styles.contextItemText, { color: item.color }]}>
                  {item.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Modal>
      )}

      {toast && (
        <ToastMessage
          message={toast.message}
          type={toast.type}
          visible={!!toast}
          onHide={() => setToast(null)}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  projectSelector: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  projectName: { fontSize: 14, fontWeight: '600' },
  chevron: { fontSize: 12 },
  addBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addBtnText: { color: '#fff', fontSize: 20, lineHeight: 24, fontWeight: '300' },
  projectList: {
    borderWidth: 1,
    borderRadius: 8,
    margin: 8,
    overflow: 'hidden',
    zIndex: 10,
  },
  newProjectRow: { padding: 12 },
  newProjectText: { fontSize: 13, fontWeight: '600' },
  projectRow: { padding: 12, borderTopWidth: StyleSheet.hairlineWidth },
  projectRowText: { fontSize: 13 },
  tree: { flex: 1 },
  treeContent: { flexGrow: 1 },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    gap: 8,
    minHeight: 300,
  },
  emptyEmoji: { fontSize: 48 },
  emptyTitle: { fontSize: 18, fontWeight: '700' },
  emptySubtitle: { fontSize: 13, textAlign: 'center' },
  ctaButton: {
    marginTop: 12,
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 8,
  },
  ctaButtonText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  modalBackdrop: {
    flex: 1,
    backgroundColor: '#00000088',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCard: {
    width: '80%',
    borderRadius: 12,
    borderWidth: 1,
    padding: 20,
    gap: 14,
  },
  modalTitle: { fontSize: 16, fontWeight: '700' },
  modalInput: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  modalActions: { flexDirection: 'row', gap: 10 },
  modalBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalBtnText: { fontWeight: '600', fontSize: 14 },
  contextBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#00000066',
  },
  contextMenu: {
    position: 'absolute',
    bottom: 100,
    left: 20,
    right: 20,
    borderRadius: 12,
    borderWidth: 1,
    overflow: 'hidden',
  },
  contextTitle: {
    padding: 12,
    fontSize: 12,
    fontFamily: 'JetBrainsMono-Regular',
  },
  contextItem: { padding: 14, borderTopWidth: StyleSheet.hairlineWidth },
  contextItemText: { fontSize: 14, fontWeight: '500' },
});
