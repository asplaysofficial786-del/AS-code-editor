import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  TextInput, StyleSheet, SafeAreaView, Alert,
} from 'react-native';
import { useTheme } from '../hooks/useTheme';
import {
  gitInit, gitStatus, gitAddAll, gitCommit,
  gitClone, gitPull, gitPush, gitLog,
  storePAT, getPAT, clearPAT, GitStatusEntry, GitLogEntry,
} from '../services/gitService';
import { useFileStore } from '../store/fileStore';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ToastMessage, { ToastType } from '../components/common/ToastMessage';

type Panel = 'status' | 'commit' | 'remote' | 'log';

export default function GitScreen() {
  const theme = useTheme();
  const { currentProjectPath, currentProjectName } = useFileStore();
  const [panel, setPanel] = useState<Panel>('status');
  const [statusEntries, setStatusEntries] = useState<GitStatusEntry[]>([]);
  const [logEntries, setLogEntries]       = useState<GitLogEntry[]>([]);
  const [commitMsg, setCommitMsg]         = useState('');
  const [remoteUrl, setRemoteUrl]         = useState('');
  const [cloneUrl, setCloneUrl]           = useState('');
  const [isLoading, setIsLoading]         = useState(false);
  const [logLines, setLogLines]           = useState<string[]>([]);
  const [toast, setToast]                 = useState<{ message: string; type: ToastType } | null>(null);

  const dir = currentProjectPath;
  const hasProject = !!dir;

  const log = useCallback((msg: string) => {
    setLogLines(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev.slice(0, 49)]);
  }, []);

  const showToast = useCallback((message: string, type: ToastType = 'info') => {
    setToast({ message, type });
  }, []);

  const run = useCallback(async (label: string, fn: () => Promise<void>) => {
    setIsLoading(true);
    log(`Starting: ${label}`);
    try {
      await fn();
      log(`✓ Done: ${label}`);
      showToast(label + ' succeeded', 'success');
    } catch (err: any) {
      const msg = err?.message ?? String(err);
      log(`✗ Error: ${msg}`);
      if (msg.includes('401') || msg.includes('403') || msg.includes('auth')) {
        await clearPAT();
        showToast('Auth failed — PAT cleared. Re-enter in Remote panel.', 'error');
      } else {
        showToast(msg, 'error');
      }
    } finally {
      setIsLoading(false);
    }
  }, [log, showToast]);

  const handleStatus = () => run('Git Status', async () => {
    const entries = await gitStatus(dir);
    setStatusEntries(entries);
  });

  const handleInit = () => run('Git Init', () => gitInit(dir));

  const handleCommitAll = () => {
    if (!commitMsg.trim()) { showToast('Enter a commit message first', 'warning'); return; }
    run('Add & Commit', async () => {
      await gitAddAll(dir);
      const sha = await gitCommit(dir, commitMsg.trim());
      log(`Committed: ${sha}`);
      setCommitMsg('');
      setStatusEntries([]);
    });
  };

  const handlePull = () => run('Git Pull', () => gitPull(dir, remoteUrl));
  const handlePush = () => run('Git Push', () => gitPush(dir, remoteUrl));

  const handleClone = () => run('Git Clone', async () => {
    await gitClone(cloneUrl, dir, (stage, loaded, total) => {
      log(`${stage}: ${loaded}/${total}`);
    });
  });

  const handleLog = () => run('Git Log', async () => {
    const entries = await gitLog(dir);
    setLogEntries(entries);
    setPanel('log');
  });

  const handleStorePAT = () => {
    Alert.prompt('GitHub / GitLab PAT', 'Paste your Personal Access Token:', async (token) => {
      if (token?.trim()) {
        await storePAT(token.trim());
        showToast('PAT saved securely ✓', 'success');
      }
    }, 'secure-text');
  };

  const PANELS: Panel[] = ['status', 'commit', 'remote', 'log'];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border }]}>
        <Text style={[styles.headerTitle, { color: theme.colors.text }]}>🌿 Git</Text>
        {hasProject && (
          <Text style={[styles.projectTag, { color: theme.colors.muted, fontFamily: 'JetBrainsMono-Regular' }]}>
            {currentProjectName}
          </Text>
        )}
      </View>

      {!hasProject ? (
        <View style={styles.noProject}>
          <Text style={styles.noProjectEmoji}>🌿</Text>
          <Text style={[styles.noProjectText, { color: theme.colors.muted }]}>
            Open a project in Explorer first
          </Text>
        </View>
      ) : (
        <>
          {/* Panel tabs */}
          <View style={[styles.tabs, { borderBottomColor: theme.colors.border }]}>
            {PANELS.map(p => (
              <TouchableOpacity
                key={p}
                onPress={() => setPanel(p)}
                style={[styles.tab, panel === p && { borderBottomColor: theme.colors.accent, borderBottomWidth: 2 }]}
              >
                <Text style={[styles.tabText, { color: panel === p ? theme.colors.accent : theme.colors.muted }]}>
                  {p.charAt(0).toUpperCase() + p.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
            {isLoading && <View style={styles.loading}><LoadingSpinner label="Working..." /></View>}

            {/* STATUS PANEL */}
            {panel === 'status' && (
              <View style={{ gap: 10 }}>
                <View style={styles.actionRow}>
                  <ActionBtn label="↻ Refresh" onPress={handleStatus} color={theme.colors.accent} theme={theme} />
                  <ActionBtn label="git init"   onPress={handleInit}   color={theme.colors.muted}  theme={theme} />
                  <ActionBtn label="📋 Log"      onPress={handleLog}    color={theme.colors.muted}  theme={theme} />
                </View>
                {statusEntries.length === 0 ? (
                  <Text style={[styles.empty, { color: theme.colors.muted }]}>
                    Press Refresh to check status
                  </Text>
                ) : (
                  statusEntries.map(e => (
                    <View key={e.filepath} style={[styles.statusRow, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
                      <View style={[styles.statusBadge, { backgroundColor: e.color + '22' }]}>
                        <Text style={[styles.statusBadgeText, { color: e.color }]}>{e.statusLabel}</Text>
                      </View>
                      <Text style={[styles.filepath, { color: theme.colors.text, fontFamily: 'JetBrainsMono-Regular' }]}>{e.filepath}</Text>
                    </View>
                  ))
                )}
              </View>
            )}

            {/* COMMIT PANEL */}
            {panel === 'commit' && (
              <View style={{ gap: 12 }}>
                <Text style={[styles.label, { color: theme.colors.muted }]}>Commit Message</Text>
                <TextInput
                  style={[styles.commitInput, { color: theme.colors.text, backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}
                  value={commitMsg}
                  onChangeText={setCommitMsg}
                  placeholder="feat: add new feature"
                  placeholderTextColor={theme.colors.muted}
                  multiline
                  numberOfLines={3}
                />
                <ActionBtn label="✓ Stage All & Commit" onPress={handleCommitAll} color={theme.colors.success} theme={theme} fullWidth />
              </View>
            )}

            {/* REMOTE PANEL */}
            {panel === 'remote' && (
              <View style={{ gap: 12 }}>
                <Text style={[styles.label, { color: theme.colors.muted }]}>Remote URL (HTTPS)</Text>
                <TextInput
                  style={[styles.urlInput, { color: theme.colors.text, backgroundColor: theme.colors.surface, borderColor: theme.colors.border, fontFamily: 'JetBrainsMono-Regular' }]}
                  value={remoteUrl}
                  onChangeText={setRemoteUrl}
                  placeholder="https://github.com/user/repo.git"
                  placeholderTextColor={theme.colors.muted}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                <View style={styles.actionRow}>
                  <ActionBtn label="⬇ Pull" onPress={handlePull} color={theme.colors.accent} theme={theme} />
                  <ActionBtn label="⬆ Push" onPress={handlePush} color={theme.colors.success} theme={theme} />
                </View>
                <View style={[styles.divider, { backgroundColor: theme.colors.border }]} />
                <Text style={[styles.label, { color: theme.colors.muted }]}>Clone URL</Text>
                <TextInput
                  style={[styles.urlInput, { color: theme.colors.text, backgroundColor: theme.colors.surface, borderColor: theme.colors.border, fontFamily: 'JetBrainsMono-Regular' }]}
                  value={cloneUrl}
                  onChangeText={setCloneUrl}
                  placeholder="https://github.com/user/repo.git"
                  placeholderTextColor={theme.colors.muted}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                <ActionBtn label="📥 Clone into project" onPress={handleClone} color={theme.colors.warning} theme={theme} fullWidth />
                <View style={[styles.divider, { backgroundColor: theme.colors.border }]} />
                <ActionBtn label="🔑 Set Personal Access Token" onPress={handleStorePAT} color={theme.colors.muted} theme={theme} fullWidth />
              </View>
            )}

            {/* LOG PANEL */}
            {panel === 'log' && (
              <View style={{ gap: 8 }}>
                <ActionBtn label="↻ Refresh Log" onPress={handleLog} color={theme.colors.accent} theme={theme} />
                {logEntries.map(e => (
                  <View key={e.oid} style={[styles.logEntry, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
                    <Text style={[styles.logHash, { color: theme.colors.accent, fontFamily: 'JetBrainsMono-Regular' }]}>{e.oid}</Text>
                    <Text style={[styles.logMsg, { color: theme.colors.text }]}>{e.message}</Text>
                    <Text style={[styles.logMeta, { color: theme.colors.muted }]}>{e.author} · {e.date.toLocaleDateString()}</Text>
                  </View>
                ))}
                {logEntries.length === 0 && (
                  <Text style={[styles.empty, { color: theme.colors.muted }]}>No commits yet</Text>
                )}
              </View>
            )}
          </ScrollView>

          {/* Operation log */}
          {logLines.length > 0 && (
            <View style={[styles.opLog, { backgroundColor: theme.colors.terminal, borderTopColor: theme.colors.border }]}>
              <ScrollView style={{ maxHeight: 80 }}>
                {logLines.slice(0, 5).map((l, i) => (
                  <Text key={i} style={[styles.opLogLine, { color: theme.colors.muted, fontFamily: 'JetBrainsMono-Regular' }]}>{l}</Text>
                ))}
              </ScrollView>
            </View>
          )}
        </>
      )}

      {toast && <ToastMessage message={toast.message} type={toast.type} visible onHide={() => setToast(null)} />}
    </SafeAreaView>
  );
}

function ActionBtn({ label, onPress, color, theme, fullWidth }: any) {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.actionButton, { backgroundColor: color + '22', borderColor: color + '44', flex: fullWidth ? undefined : 1 }]}
    >
      <Text style={[styles.actionButtonText, { color }]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1 },
  header:          { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, gap: 10 },
  headerTitle:     { fontSize: 20, fontWeight: '700', flex: 1 },
  projectTag:      { fontSize: 12 },
  noProject:       { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  noProjectEmoji:  { fontSize: 48 },
  noProjectText:   { fontSize: 14 },
  tabs:            { flexDirection: 'row', borderBottomWidth: 1 },
  tab:             { flex: 1, paddingVertical: 10, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabText:         { fontSize: 12, fontWeight: '600' },
  scroll:          { flex: 1 },
  content:         { padding: 14, gap: 0, paddingBottom: 20 },
  loading:         { paddingVertical: 12, alignItems: 'flex-start' },
  actionRow:       { flexDirection: 'row', gap: 8 },
  actionButton:    { paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8, borderWidth: 1, alignItems: 'center' },
  actionButtonText:{ fontSize: 12, fontWeight: '600' },
  empty:           { fontSize: 13, textAlign: 'center', paddingVertical: 24 },
  statusRow:       { flexDirection: 'row', alignItems: 'center', padding: 10, borderRadius: 8, borderWidth: 1, gap: 10 },
  statusBadge:     { width: 22, height: 22, borderRadius: 4, alignItems: 'center', justifyContent: 'center' },
  statusBadgeText: { fontSize: 11, fontWeight: '800' },
  filepath:        { fontSize: 12, flex: 1 },
  label:           { fontSize: 12, fontWeight: '600', letterSpacing: 0.5 },
  commitInput:     { borderWidth: 1, borderRadius: 8, padding: 12, fontSize: 13, minHeight: 80, textAlignVertical: 'top' },
  urlInput:        { borderWidth: 1, borderRadius: 8, padding: 10, fontSize: 12 },
  divider:         { height: 1, marginVertical: 4 },
  logEntry:        { borderRadius: 8, borderWidth: 1, padding: 10, gap: 3 },
  logHash:         { fontSize: 11 },
  logMsg:          { fontSize: 13, fontWeight: '500' },
  logMeta:         { fontSize: 11 },
  opLog:           { maxHeight: 90, borderTopWidth: 1, padding: 8 },
  opLogLine:       { fontSize: 10, lineHeight: 16 },
});
