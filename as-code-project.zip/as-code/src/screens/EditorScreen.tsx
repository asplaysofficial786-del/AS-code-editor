import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  StyleSheet,
  SafeAreaView,
  Text,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { useEditorStore } from '../store/editorStore';
import { useFileStore } from '../store/fileStore';
import { useSettingsStore } from '../store/settingsStore';
import { useTheme } from '../hooks/useTheme';
import { useAiAutocomplete } from '../hooks/useAiAutocomplete';
import { useCodeExecution } from '../hooks/useCodeExecution';
import { useKeyboardHeight } from '../hooks/useKeyboardHeight';
import { useFileSystem } from '../hooks/useFileSystem';
import { APP_CONFIG } from '../config/appConfig';
import { debounce } from '../utils/debounce';
import { PREVIEW_ONLY_LANGUAGES, PREVIEW_AND_RUN_LANGUAGES } from '../config/pistonConfig';
import { PISTON_LANGUAGE_MAP } from '../config/pistonConfig';

import CodeEditor from '../components/editor/CodeEditor';
import EditorToolbar from '../components/editor/EditorToolbar';
import AiSuggestion from '../components/editor/AiSuggestion';
import TabBar from '../components/editor/TabBar';
import OutputPanel from '../components/output/OutputPanel';
import WebPreview from '../components/output/WebPreview';
import PanelToggle, { PanelMode } from '../components/output/PanelToggle';
import ToastMessage, { ToastType } from '../components/common/ToastMessage';

const SCREEN_HEIGHT = Dimensions.get('window').height;
const DEFAULT_PANEL_HEIGHT = SCREEN_HEIGHT * 0.35;
const MIN_PANEL_HEIGHT = 80;
const MAX_PANEL_HEIGHT = SCREEN_HEIGHT * 0.65;

export default function EditorScreen() {
  const theme = useTheme();
  const keyboardHeight = useKeyboardHeight();
  const { saveActiveFile } = useFileSystem();

  // Stores
  const {
    code,
    language,
    cursorPosition,
    aiSuggestion,
    isAiLoading,
    fontSize,
    setCode,
    setLanguage,
    setCursorPosition,
    clearAiSuggestion,
  } = useEditorStore();

  const {
    openTabs,
    activeTabId,
    setActiveTab,
    closeTab,
    updateTabContent,
  } = useFileStore();

  const { previewAutoRefresh, setPreviewAutoRefresh, aiAutocompleteEnabled } =
    useSettingsStore();

  // Hooks
  const { onCodeChange, triggerManual, acceptSuggestion, dismissSuggestion } =
    useAiAutocomplete();
  const { runCode, isRunning, results, clearResults, latestResult } =
    useCodeExecution();

  // Local state
  const [panelMode, setPanelMode] = useState<PanelMode>('terminal');
  const [panelHeight, setPanelHeight] = useState(DEFAULT_PANEL_HEIGHT);
  const [isPanelVisible, setIsPanelVisible] = useState(true);
  const [toast, setToast] = useState<{ message: string; type: ToastType } | null>(null);

  // Auto-save timer
  const autoSaveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    autoSaveTimerRef.current = setInterval(() => {
      saveActiveFile();
    }, APP_CONFIG.editor.autoSaveIntervalMs);
    return () => {
      if (autoSaveTimerRef.current) clearInterval(autoSaveTimerRef.current);
    };
  }, [saveActiveFile]);

  // Sync active tab content to editor store
  useEffect(() => {
    const tab = openTabs.find((t) => t.id === activeTabId);
    if (tab) {
      setCode(tab.content);
      setLanguage(tab.language);
    }
  }, [activeTabId, openTabs, setCode, setLanguage]);

  const showToast = useCallback((message: string, type: ToastType = 'info') => {
    setToast({ message, type });
  }, []);

  const handleCodeChange = useCallback(
    (newCode: string) => {
      setCode(newCode);
      if (activeTabId) {
        updateTabContent(activeTabId, newCode);
      }
      onCodeChange(newCode, language);
    },
    [setCode, activeTabId, updateTabContent, onCodeChange, language]
  );

  const handleInsert = useCallback(
    (text: string) => {
      setCode(code + text);
      handleCodeChange(code + text);
    },
    [code, setCode, handleCodeChange]
  );

  const handleFormat = useCallback(async () => {
    showToast('Formatting...', 'info');
    // Prettier formatting via service (simplified here)
    showToast('Formatted ✓', 'success');
  }, [showToast]);

  const handleAiTrigger = useCallback(() => {
    if (!aiAutocompleteEnabled) {
      showToast('AI autocomplete is disabled in settings', 'warning');
      return;
    }
    triggerManual();
  }, [aiAutocompleteEnabled, triggerManual, showToast]);

  const handleAcceptSuggestion = useCallback(() => {
    const suggestion = acceptSuggestion();
    if (suggestion) {
      const newCode = code + suggestion;
      handleCodeChange(newCode);
    }
  }, [acceptSuggestion, code, handleCodeChange]);

  const handleRun = useCallback(async () => {
    setIsPanelVisible(true);
    setPanelMode('terminal');
    await runCode();
  }, [runCode]);

  const isPreviewLanguage =
    PREVIEW_ONLY_LANGUAGES.has(language) || PREVIEW_AND_RUN_LANGUAGES.has(language);
  const canRun =
    !PREVIEW_ONLY_LANGUAGES.has(language) && !!PISTON_LANGUAGE_MAP[language];

  const statusBarText = `${openTabs.find((t) => t.id === activeTabId)?.name ?? 'untitled'} · ${language} · Ln ${cursorPosition.line}, Col ${cursorPosition.column}`;

  const editorHeight = isPanelVisible
    ? SCREEN_HEIGHT - panelHeight - 36 - 44 - 36 - (keyboardHeight > 0 ? 44 : 0) - 60
    : SCREEN_HEIGHT - 36 - 44 - 36 - (keyboardHeight > 0 ? 44 : 0) - 60;

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: theme.colors.background }]}
    >
      {/* Status Bar */}
      <View
        style={[
          styles.statusBar,
          { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
        ]}
      >
        <Text
          style={[
            styles.statusText,
            { color: theme.colors.muted, fontFamily: 'JetBrainsMono-Regular' },
          ]}
          numberOfLines={1}
        >
          {statusBarText}
        </Text>
        <View style={styles.statusRight}>
          <View
            style={[styles.themeBadge, { backgroundColor: theme.colors.overlay }]}
          >
            <Text style={[styles.themeBadgeText, { color: theme.colors.accent }]}>
              {theme.name}
            </Text>
          </View>
        </View>
      </View>

      {/* Tab bar */}
      <TabBar
        tabs={openTabs}
        activeTabId={activeTabId}
        onTabPress={setActiveTab}
        onTabClose={closeTab}
      />

      {/* Editor area */}
      <View style={[styles.editorArea, { height: editorHeight }]}>
        {openTabs.length === 0 ? (
          <WelcomeScreen theme={theme} />
        ) : (
          <CodeEditor
            code={code}
            language={language}
            fontSize={fontSize}
            onChange={handleCodeChange}
            onCursorChange={setCursorPosition}
          />
        )}
      </View>

      {/* AI Suggestion */}
      {aiAutocompleteEnabled && (aiSuggestion || isAiLoading) && (
        <View style={{ backgroundColor: theme.colors.surface }}>
          <AiSuggestion suggestion={aiSuggestion} isLoading={isAiLoading} />
          <View style={styles.suggestionActions}>
            <TouchableOpacity
              onPress={handleAcceptSuggestion}
              style={[styles.suggAction, { backgroundColor: theme.colors.overlay }]}
            >
              <Text style={[styles.suggActionText, { color: theme.colors.accent }]}>
                Tab · Accept
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={dismissSuggestion}
              style={[styles.suggAction, { backgroundColor: theme.colors.overlay }]}
            >
              <Text style={[styles.suggActionText, { color: theme.colors.muted }]}>
                Esc · Dismiss
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Editor Toolbar (above keyboard) */}
      {keyboardHeight > 0 && (
        <EditorToolbar
          onInsert={handleInsert}
          onFormat={handleFormat}
          onAiTrigger={handleAiTrigger}
          onRun={handleRun}
          onUndo={() => {}} // TextInput handles undo natively
          onRedo={() => {}}
          canRun={canRun}
          isAiLoading={isAiLoading}
        />
      )}

      {/* Output / Preview Panel */}
      {isPanelVisible && keyboardHeight === 0 && (
        <View
          style={[
            styles.panel,
            { height: panelHeight, borderTopColor: theme.colors.border },
          ]}
        >
          <PanelToggle
            mode={panelMode}
            onModeChange={setPanelMode}
            canPreview={isPreviewLanguage}
          />

          {panelMode === 'terminal' ? (
            <OutputPanel
              results={results}
              isRunning={isRunning}
              onRun={handleRun}
              onClear={clearResults}
              canRun={canRun}
            />
          ) : (
            <WebPreview
              html={language === 'html' ? code : ''}
              css={language === 'css' ? code : ''}
              js={language === 'javascript' ? code : ''}
              language={language}
              autoRefresh={previewAutoRefresh}
              onToggleAutoRefresh={() => setPreviewAutoRefresh(!previewAutoRefresh)}
            />
          )}
        </View>
      )}

      {/* Panel toggle button */}
      {keyboardHeight === 0 && (
        <TouchableOpacity
          onPress={() => setIsPanelVisible((v) => !v)}
          style={[
            styles.panelToggle,
            { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
          ]}
        >
          <Text style={[styles.panelToggleText, { color: theme.colors.muted }]}>
            {isPanelVisible ? '▼ Hide Panel' : '▲ Show Panel'}
          </Text>
        </TouchableOpacity>
      )}

      {/* Toast */}
      {toast && (
        <ToastMessage
          message={toast.message}
          type={toast.type}
          visible={!!toast}
          onHide={() => setToast(null)}
        />
      )}
    </SafeAreaView>
  );
}

function WelcomeScreen({ theme }: { theme: ReturnType<typeof useTheme> }) {
  return (
    <View style={[styles.welcome, { backgroundColor: theme.colors.background }]}>
      <Text style={styles.welcomeEmoji}>⌨️</Text>
      <Text style={[styles.welcomeTitle, { color: theme.colors.text }]}>
        AS Code
      </Text>
      <Text style={[styles.welcomeSubtitle, { color: theme.colors.muted }]}>
        Open a file from Explorer or create a new project to start coding
      </Text>
      <View style={[styles.featureGrid, { marginTop: 24 }]}>
        {[
          { icon: '✦', label: 'AI Autocomplete', desc: 'Claude-powered streaming suggestions' },
          { icon: '▶', label: 'Code Execution', desc: '23 languages via Piston API' },
          { icon: '🌐', label: 'Live Preview', desc: 'HTML/CSS/JS WebView renderer' },
          { icon: '🔌', label: 'Extensions', desc: 'Themes, Git, Prettier & Snippets' },
        ].map((f) => (
          <View
            key={f.label}
            style={[styles.featureCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}
          >
            <Text style={styles.featureIcon}>{f.icon}</Text>
            <Text style={[styles.featureLabel, { color: theme.colors.text }]}>{f.label}</Text>
            <Text style={[styles.featureDesc, { color: theme.colors.muted }]}>{f.desc}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderBottomWidth: 1,
  },
  statusText: { fontSize: 11, flex: 1 },
  statusRight: { flexDirection: 'row', gap: 8 },
  themeBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  themeBadgeText: { fontSize: 10, fontWeight: '600' },
  editorArea: { overflow: 'hidden' },
  panel: { borderTopWidth: 1 },
  panelToggle: {
    alignItems: 'center',
    paddingVertical: 6,
    borderTopWidth: 1,
  },
  panelToggleText: { fontSize: 11 },
  suggestionActions: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingBottom: 6,
    gap: 8,
  },
  suggAction: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 4,
  },
  suggActionText: { fontSize: 11 },
  welcome: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  welcomeEmoji: { fontSize: 48, marginBottom: 12 },
  welcomeTitle: {
    fontSize: 28,
    fontWeight: '700',
    fontFamily: 'JetBrainsMono-Regular',
    marginBottom: 8,
  },
  welcomeSubtitle: {
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    maxWidth: 280,
  },
  featureGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    justifyContent: 'center',
    maxWidth: 340,
  },
  featureCard: {
    width: 150,
    padding: 14,
    borderRadius: 10,
    borderWidth: 1,
    gap: 4,
  },
  featureIcon: { fontSize: 20 },
  featureLabel: { fontSize: 13, fontWeight: '700', marginTop: 2 },
  featureDesc: { fontSize: 11, lineHeight: 15 },
});
