import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
  TextInput,
  SafeAreaView,
} from 'react-native';
import { useSettingsStore } from '../store/settingsStore';
import { useTheme } from '../hooks/useTheme';
import { PISTON_LANGUAGE_MAP } from '../config/pistonConfig';
import Badge from '../components/common/Badge';
import { useNavigation } from '@react-navigation/native';

type Section = {
  title: string;
  items: React.ReactNode[];
};

export default function SettingsScreen() {
  const theme = useTheme();
  const navigation = useNavigation();
  const settings = useSettingsStore();

  const renderSection = useCallback(
    ({ title, items }: Section) => (
      <View key={title} style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.colors.accent }]}>
          {title.toUpperCase()}
        </Text>
        <View
          style={[
            styles.sectionCard,
            { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
          ]}
        >
          {items.map((item, i) => (
            <View key={i}>
              {i > 0 && (
                <View
                  style={[styles.divider, { backgroundColor: theme.colors.border }]}
                />
              )}
              {item}
            </View>
          ))}
        </View>
      </View>
    ),
    [theme]
  );

  const row = (label: string, control: React.ReactNode, description?: string) => (
    <View style={styles.row}>
      <View style={styles.rowLeft}>
        <Text style={[styles.rowLabel, { color: theme.colors.text }]}>{label}</Text>
        {description && (
          <Text style={[styles.rowDesc, { color: theme.colors.muted }]}>
            {description}
          </Text>
        )}
      </View>
      {control}
    </View>
  );

  const toggleRow = (
    label: string,
    value: boolean,
    onChange: (v: boolean) => void,
    description?: string
  ) =>
    row(
      label,
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ false: theme.colors.border, true: theme.colors.accent + '66' }}
        thumbColor={value ? theme.colors.accent : theme.colors.muted}
      />,
      description
    );

  const stepperRow = (
    label: string,
    value: number,
    min: number,
    max: number,
    step: number,
    onChange: (v: number) => void,
    description?: string
  ) =>
    row(
      label,
      <View style={styles.stepper}>
        <TouchableOpacity
          onPress={() => onChange(Math.max(min, value - step))}
          style={[styles.stepBtn, { backgroundColor: theme.colors.overlay }]}
        >
          <Text style={[styles.stepBtnText, { color: theme.colors.text }]}>−</Text>
        </TouchableOpacity>
        <Text
          style={[
            styles.stepValue,
            { color: theme.colors.text, fontFamily: 'JetBrainsMono-Regular' },
          ]}
        >
          {value}
        </Text>
        <TouchableOpacity
          onPress={() => onChange(Math.min(max, value + step))}
          style={[styles.stepBtn, { backgroundColor: theme.colors.overlay }]}
        >
          <Text style={[styles.stepBtnText, { color: theme.colors.text }]}>+</Text>
        </TouchableOpacity>
      </View>,
      description
    );

  const pistonModeSection = (
    <View style={styles.row}>
      <View style={styles.rowLeft}>
        <Text style={[styles.rowLabel, { color: theme.colors.text }]}>
          Piston API Mode
        </Text>
        <Text style={[styles.rowDesc, { color: theme.colors.muted }]}>
          Switch between public and self-hosted Piston
        </Text>
        <View style={[styles.pistonModeBadge]}>
          <Badge
            label={settings.pistonMode === 'public' ? '🌐 Public API' : '🏠 Self-Hosted'}
            color={settings.pistonMode === 'public' ? theme.colors.accent : theme.colors.success}
            backgroundColor={
              settings.pistonMode === 'public'
                ? theme.colors.accent + '22'
                : theme.colors.success + '22'
            }
            size="sm"
          />
        </View>
      </View>
      <TouchableOpacity
        onPress={() =>
          settings.setPistonMode(
            settings.pistonMode === 'public' ? 'self-hosted' : 'public'
          )
        }
        style={[styles.toggleBtn, { backgroundColor: theme.colors.overlay }]}
      >
        <Text style={[styles.toggleBtnText, { color: theme.colors.accent }]}>
          Switch
        </Text>
      </TouchableOpacity>
    </View>
  );

  const selfHostedUrlRow = settings.pistonMode === 'self-hosted' && (
    <View style={[styles.row, styles.urlRow]}>
      <Text style={[styles.rowLabel, { color: theme.colors.text }]}>Server URL</Text>
      <TextInput
        style={[
          styles.urlInput,
          {
            color: theme.colors.text,
            backgroundColor: theme.colors.overlay,
            borderColor: theme.colors.border,
            fontFamily: 'JetBrainsMono-Regular',
          },
        ]}
        value={settings.pistonSelfHostedUrl}
        onChangeText={settings.setPistonSelfHostedUrl}
        placeholder="http://localhost:2000/api/v2"
        placeholderTextColor={theme.colors.muted}
        autoCapitalize="none"
        autoCorrect={false}
      />
    </View>
  );

  const sections: Section[] = [
    {
      title: '✏️ Editor',
      items: [
        stepperRow('Font Size', settings.fontSize, 10, 24, 1, settings.setFontSize, 'Editor text size in sp'),
        stepperRow('Tab Size', settings.tabSize, 2, 8, 2, settings.setTabSize, 'Spaces per indent level'),
        toggleRow('Line Numbers', settings.lineNumbers, settings.setLineNumbers),
        toggleRow('Word Wrap', settings.wordWrap, settings.setWordWrap),
        toggleRow('Auto Save', settings.autoSave, settings.setAutoSave, 'Save every 30 seconds automatically'),
        toggleRow('Auto Close Brackets', settings.autoCloseBrackets, settings.setAutoCloseBrackets),
        toggleRow('Auto Close Quotes', settings.autoCloseQuotes, settings.setAutoCloseQuotes),
      ].filter(Boolean) as React.ReactNode[],
    },
    {
      title: '✦ AI Autocomplete',
      items: [
        toggleRow(
          'Enable AI Autocomplete',
          settings.aiAutocompleteEnabled,
          settings.setAiAutocompleteEnabled,
          'Powered by Claude API (requires API key)'
        ),
        row(
          'Trigger Mode',
          <View style={styles.segmented2}>
            {(['as-you-type', 'manual'] as const).map((m) => (
              <TouchableOpacity
                key={m}
                onPress={() => settings.setAiTriggerMode(m)}
                style={[
                  styles.seg2,
                  { backgroundColor: theme.colors.overlay },
                  settings.aiTriggerMode === m && { backgroundColor: theme.colors.accent + '33' },
                ]}
              >
                <Text
                  style={[
                    styles.seg2Text,
                    {
                      color:
                        settings.aiTriggerMode === m
                          ? theme.colors.accent
                          : theme.colors.muted,
                    },
                  ]}
                >
                  {m === 'as-you-type' ? 'Auto' : 'Manual'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        ),
      ],
    },
    {
      title: '▶ Execution',
      items: [
        pistonModeSection,
        ...(selfHostedUrlRow ? [selfHostedUrlRow] : []),
        toggleRow(
          'WiFi-only Doc Downloads',
          settings.downloadDocsOnWifiOnly,
          settings.setDownloadDocsOnWifiOnly,
          'Only download full docs on WiFi'
        ),
      ],
    },
    {
      title: '🌐 Preview',
      items: [
        toggleRow(
          'Auto-Refresh Preview',
          settings.previewAutoRefresh,
          settings.setPreviewAutoRefresh,
          'Refresh live preview after 800ms of inactivity'
        ),
        row(
          'Preview Layout',
          <View style={styles.segmented2}>
            {(['split', 'fullscreen'] as const).map((m) => (
              <TouchableOpacity
                key={m}
                onPress={() => settings.setPreviewLayout(m)}
                style={[
                  styles.seg2,
                  { backgroundColor: theme.colors.overlay },
                  settings.previewLayout === m && {
                    backgroundColor: theme.colors.accent + '33',
                  },
                ]}
              >
                <Text
                  style={[
                    styles.seg2Text,
                    {
                      color:
                        settings.previewLayout === m
                          ? theme.colors.accent
                          : theme.colors.muted,
                    },
                  ]}
                >
                  {m}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        ),
      ],
    },
    {
      title: 'ℹ️ About',
      items: [
        row('Version', <Text style={[styles.mono, { color: theme.colors.muted }]}>1.0.0</Text>),
        row(
          'About & Credits',
          <TouchableOpacity
            onPress={() => (navigation as any).navigate('About')}
            style={[styles.linkBtn, { borderColor: theme.colors.border }]}
          >
            <Text style={[styles.linkBtnText, { color: theme.colors.accent }]}>View →</Text>
          </TouchableOpacity>
        ),
      ],
    },
  ];

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: theme.colors.background }]}
    >
      <View
        style={[
          styles.header,
          { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: theme.colors.text }]}>Settings</Text>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {sections.map(renderSection)}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: 20, fontWeight: '700' },
  scroll: { flex: 1 },
  content: { padding: 12, gap: 16, paddingBottom: 40 },
  section: { gap: 6 },
  sectionTitle: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.2,
    paddingHorizontal: 4,
  },
  sectionCard: {
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
  },
  divider: { height: StyleSheet.hairlineWidth },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 12,
  },
  rowLeft: { flex: 1, gap: 2 },
  rowLabel: { fontSize: 14 },
  rowDesc: { fontSize: 11, lineHeight: 15 },
  pistonModeBadge: { marginTop: 6 },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stepBtn: {
    width: 28,
    height: 28,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepBtnText: { fontSize: 16 },
  stepValue: { fontSize: 14, minWidth: 24, textAlign: 'center' },
  segmented2: { flexDirection: 'row', gap: 4 },
  seg2: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 6,
  },
  seg2Text: { fontSize: 11, fontWeight: '600' },
  toggleBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  toggleBtnText: { fontSize: 13, fontWeight: '600' },
  urlRow: { flexDirection: 'column', alignItems: 'stretch', gap: 6 },
  urlInput: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 12,
  },
  mono: { fontSize: 13, fontFamily: 'JetBrainsMono-Regular' },
  linkBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    borderWidth: 1,
  },
  linkBtnText: { fontSize: 13, fontWeight: '600' },
});
