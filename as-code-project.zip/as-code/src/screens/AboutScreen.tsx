import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import { useTheme } from '../hooks/useTheme';
import Badge from '../components/common/Badge';

const LANGUAGE_SUPPORT = [
  { lang: 'HTML',       syntax: true,  ai: true,  compile: false, preview: true  },
  { lang: 'CSS',        syntax: true,  ai: true,  compile: false, preview: true  },
  { lang: 'JavaScript', syntax: true,  ai: true,  compile: true,  preview: true  },
  { lang: 'TypeScript', syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Python',     syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'C',          syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'C++',        syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Java',       syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Kotlin',     syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Go',         syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Rust',       syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'PHP',        syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Ruby',       syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Bash',       syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Lua',        syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'C#',         syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Dart',       syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Swift',      syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'R',          syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Scala',      syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Haskell',    syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Elixir',     syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'Julia',      syntax: true,  ai: true,  compile: true,  preview: false },
  { lang: 'AS Lang 🚧', syntax: null,  ai: null,  compile: null,  preview: null  },
];

export default function AboutScreen() {
  const theme = useTheme();

  const cell = (v: boolean | null) => {
    if (v === null)
      return <Text style={{ fontSize: 13 }}>🚧</Text>;
    return (
      <Text style={{ color: v ? theme.colors.success : theme.colors.muted, fontSize: 13 }}>
        {v ? '✅' : '❌'}
      </Text>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView contentContainerStyle={styles.content}>

        {/* ── Hero ── */}
        <View style={styles.hero}>
          <Text style={styles.heroEmoji}>⌨️</Text>
          <Text style={[styles.heroTitle, { color: theme.colors.text, fontFamily: 'JetBrainsMono-Regular' }]}>
            AS Code
          </Text>
          <Text style={[styles.heroSub, { color: theme.colors.muted }]}>
            AI-Powered Mobile Code Editor
          </Text>
          <View style={styles.badgeRow}>
            <Badge label="v1.0.0"        color={theme.colors.accent}  backgroundColor={theme.colors.overlay} />
            <Badge label="Android"        color={theme.colors.success} backgroundColor={theme.colors.overlay} />
            <Badge label="React Native"   color={theme.colors.muted}   backgroundColor={theme.colors.overlay} />
          </View>
        </View>

        {/* ── 🚧 AS Lang Coming Soon ── */}
        <View style={[styles.comingSoon, { backgroundColor: '#1a1500', borderColor: '#d2992266' }]}>
          <View style={[styles.warnBadge, { backgroundColor: '#d2992233' }]}>
            <Text style={styles.warnText}>🚧 COMING SOON</Text>
          </View>
          <Text style={[styles.comingSoonTitle, { color: '#e6b800' }]}>AS Lang</Text>
          <Text style={[styles.comingSoonDesc, { color: '#c9a93a' }]}>
            AS Lang — Our own custom programming language is in development.{'\n'}
            AS Lang will be natively compiled and run directly in AS Code.{'\n'}
            Stay tuned for future updates.
          </Text>
        </View>

        {/* ── Tech stack ── */}
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <Text style={[styles.cardTitle, { color: theme.colors.text }]}>Powered By</Text>
          {[
            { icon: '✦', label: 'Claude API',         desc: 'claude-sonnet-4-20250514 — streaming AI autocomplete' },
            { icon: '▶', label: 'Piston API',          desc: 'Free open-source multi-language code execution' },
            { icon: '🌿', label: 'isomorphic-git',     desc: 'Full Git operations in pure JavaScript' },
            { icon: '✨', label: 'Prettier',            desc: 'Auto code formatting via in-app WebView bridge' },
            { icon: '📱', label: 'React Native + Expo', desc: 'Cross-platform mobile with Bare Workflow' },
          ].map((item, i) => (
            <View key={item.label} style={[styles.techRow, i > 0 && { borderTopColor: theme.colors.border, borderTopWidth: StyleSheet.hairlineWidth }]}>
              <Text style={styles.techIcon}>{item.icon}</Text>
              <View>
                <Text style={[styles.techLabel, { color: theme.colors.text }]}>{item.label}</Text>
                <Text style={[styles.techDesc,  { color: theme.colors.muted }]}>{item.desc}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* ── Language Support Table ── */}
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <Text style={[styles.cardTitle, { color: theme.colors.text }]}>Language Support</Text>

          {/* Table header */}
          <View style={[styles.tableRow, styles.tableHeader, { borderBottomColor: theme.colors.border }]}>
            {['Language', 'Syntax', 'AI', 'Run', 'Preview'].map((h) => (
              <Text key={h} style={[styles.th, { color: theme.colors.muted }]}>{h}</Text>
            ))}
          </View>

          {LANGUAGE_SUPPORT.map((row, i) => (
            <View
              key={row.lang}
              style={[
                styles.tableRow,
                { borderTopColor: theme.colors.border, borderTopWidth: i > 0 ? StyleSheet.hairlineWidth : 0 },
                row.lang.includes('🚧') && { backgroundColor: '#d2992211' },
              ]}
            >
              <Text style={[styles.td, styles.tdLang, { color: row.lang.includes('🚧') ? '#e6b800' : theme.colors.text, fontFamily: 'JetBrainsMono-Regular' }]}>
                {row.lang}
              </Text>
              <View style={styles.tdCell}>{cell(row.syntax)}</View>
              <View style={styles.tdCell}>{cell(row.ai)}</View>
              <View style={styles.tdCell}>{cell(row.compile)}</View>
              <View style={styles.tdCell}>{cell(row.preview)}</View>
            </View>
          ))}
        </View>

        {/* ── Credits ── */}
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <Text style={[styles.cardTitle, { color: theme.colors.text }]}>Credits</Text>
          <Text style={[styles.credits, { color: theme.colors.muted }]}>
            Built with ❤️ using React Native, Expo, and the Anthropic Claude API.{'\n\n'}
            Font: JetBrains Mono — JetBrains s.r.o.{'\n'}
            Icons: Emoji standard{'\n'}
            Code execution: emkc.org Piston API{'\n\n'}
            © 2025 AS Code. All rights reserved.
          </Text>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1 },
  content:         { padding: 16, gap: 16, paddingBottom: 40 },
  hero:            { alignItems: 'center', paddingVertical: 24, gap: 8 },
  heroEmoji:       { fontSize: 56 },
  heroTitle:       { fontSize: 28, fontWeight: '700' },
  heroSub:         { fontSize: 14 },
  badgeRow:        { flexDirection: 'row', gap: 8, marginTop: 4 },
  comingSoon:      { borderRadius: 12, borderWidth: 1, padding: 16, gap: 10 },
  warnBadge:       { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6 },
  warnText:        { color: '#d29922', fontSize: 11, fontWeight: '700', letterSpacing: 0.8 },
  comingSoonTitle: { fontSize: 20, fontWeight: '800' },
  comingSoonDesc:  { fontSize: 13, lineHeight: 20 },
  card:            { borderRadius: 12, borderWidth: 1, overflow: 'hidden' },
  cardTitle:       { fontSize: 15, fontWeight: '700', padding: 14 },
  techRow:         { flexDirection: 'row', alignItems: 'flex-start', padding: 12, gap: 12 },
  techIcon:        { fontSize: 18, width: 24, textAlign: 'center', marginTop: 1 },
  techLabel:       { fontSize: 13, fontWeight: '600' },
  techDesc:        { fontSize: 11, marginTop: 2, lineHeight: 16 },
  tableRow:        { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 7 },
  tableHeader:     { borderBottomWidth: 1 },
  th:              { flex: 1, fontSize: 10, fontWeight: '700', letterSpacing: 0.5, textAlign: 'center' },
  td:              { flex: 1.8, fontSize: 11, textAlign: 'left' },
  tdLang:          { fontSize: 11 },
  tdCell:          { flex: 1, alignItems: 'center' },
  credits:         { fontSize: 12, lineHeight: 20, padding: 14, paddingTop: 0 },
});
