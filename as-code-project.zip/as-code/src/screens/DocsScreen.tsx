import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import { useTheme } from '../hooks/useTheme';
import SearchBar from '../components/common/SearchBar';

const SUPPORTED_LANGS = [
  { id: 'html', label: 'HTML', emoji: '🟠' },
  { id: 'css', label: 'CSS', emoji: '🔵' },
  { id: 'javascript', label: 'JS', emoji: '🟡' },
  { id: 'typescript', label: 'TS', emoji: '🔷' },
  { id: 'python', label: 'Python', emoji: '🐍' },
  { id: 'cpp', label: 'C++', emoji: '⚙️' },
  { id: 'java', label: 'Java', emoji: '☕' },
  { id: 'kotlin', label: 'Kotlin', emoji: '🟣' },
  { id: 'dart', label: 'Dart', emoji: '🎯' },
  { id: 'go', label: 'Go', emoji: '🐹' },
  { id: 'rust', label: 'Rust', emoji: '🦀' },
  { id: 'csharp', label: 'C#', emoji: '💚' },
];

// Bundled basic docs (would be loaded from assets/docs/ in production)
const BUNDLED_DOCS: Record<string, { sections: Array<{ title: string; content: string }> }> = {
  javascript: {
    sections: [
      {
        title: 'Variables',
        content: 'const x = 1; // Immutable reference\nlet y = 2;   // Mutable\nvar z = 3;   // Function-scoped (avoid)',
      },
      {
        title: 'Functions',
        content: '// Arrow function\nconst add = (a, b) => a + b;\n\n// Regular function\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}',
      },
      {
        title: 'Array Methods',
        content: 'arr.map(x => x * 2)      // Transform each element\narr.filter(x => x > 0)  // Keep matching elements\narr.reduce((acc, x) => acc + x, 0)  // Fold\narr.find(x => x > 5)    // First match\narr.includes(value)     // Contains check',
      },
      {
        title: 'Promises & Async',
        content: '// Async/await\nasync function fetchData() {\n  try {\n    const res = await fetch(url);\n    const data = await res.json();\n    return data;\n  } catch (err) {\n    console.error(err);\n  }\n}',
      },
      {
        title: 'Destructuring',
        content: '// Array destructuring\nconst [a, b] = [1, 2];\n\n// Object destructuring\nconst { name, age } = person;\n\n// With defaults\nconst { x = 0, y = 0 } = point;',
      },
    ],
  },
  python: {
    sections: [
      {
        title: 'Data Types',
        content: 'x = 42        # int\ny = 3.14      # float\ns = "hello"   # str\nb = True      # bool\nl = [1,2,3]   # list\nd = {"k": "v"} # dict\nt = (1,2)     # tuple\nnone = None   # NoneType',
      },
      {
        title: 'Control Flow',
        content: '# If/elif/else\nif x > 0:\n    print("positive")\nelif x < 0:\n    print("negative")\nelse:\n    print("zero")\n\n# For loop\nfor item in collection:\n    print(item)\n\n# While loop\nwhile condition:\n    do_something()',
      },
      {
        title: 'Functions',
        content: 'def greet(name, greeting="Hello"):\n    return f"{greeting}, {name}!"\n\n# Lambda\nsquare = lambda x: x ** 2\n\n# *args and **kwargs\ndef variadic(*args, **kwargs):\n    print(args, kwargs)',
      },
      {
        title: 'List Comprehensions',
        content: 'squares = [x**2 for x in range(10)]\nevens = [x for x in range(20) if x % 2 == 0]\nmatrix = [[i*j for j in range(3)] for i in range(3)]',
      },
      {
        title: 'Classes',
        content: 'class Animal:\n    def __init__(self, name):\n        self.name = name\n    \n    def speak(self):\n        raise NotImplementedError\n\nclass Dog(Animal):\n    def speak(self):\n        return f"{self.name} says woof!"',
      },
    ],
  },
  html: {
    sections: [
      {
        title: 'Document Structure',
        content: '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width">\n  <title>Page Title</title>\n</head>\n<body>\n  <!-- content here -->\n</body>\n</html>',
      },
      {
        title: 'Semantic Elements',
        content: '<header>  <!-- site/page header -->\n<nav>     <!-- navigation -->\n<main>    <!-- main content -->\n<article> <!-- self-contained content -->\n<section> <!-- thematic grouping -->\n<aside>   <!-- sidebar/tangential -->\n<footer>  <!-- site/page footer -->',
      },
      {
        title: 'Common Tags',
        content: '<h1>–<h6>  Headings\n<p>        Paragraph\n<a href=""> Link\n<img src="" alt="">\n<ul><li>   Unordered list\n<ol><li>   Ordered list\n<div>      Block container\n<span>     Inline container\n<button>   Clickable button\n<input>    Form input',
      },
    ],
  },
  css: {
    sections: [
      {
        title: 'Selectors',
        content: '.class      /* class selector */\n#id         /* id selector */\nelement     /* tag selector */\na, b        /* group */\na > b       /* direct child */\na + b       /* adjacent sibling */\na:hover     /* pseudo-class */\na::before   /* pseudo-element */\n[attr=val]  /* attribute */\n*           /* universal */\n',
      },
      {
        title: 'Box Model',
        content: 'margin:   space outside border\nborder:   border around padding\npadding:  space inside border\ncontent:  actual content\n\nbox-sizing: border-box; /* width includes padding+border */\ndisplay: block | inline | inline-block | flex | grid',
      },
      {
        title: 'Flexbox',
        content: '.container {\n  display: flex;\n  flex-direction: row | column;\n  justify-content: flex-start | center | space-between;\n  align-items: flex-start | center | stretch;\n  flex-wrap: wrap;\n  gap: 16px;\n}\n.item {\n  flex: 1; /* grow/shrink evenly */\n}',
      },
      {
        title: 'Grid',
        content: '.grid {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  grid-template-rows: auto;\n  gap: 16px;\n}\n.item {\n  grid-column: span 2;\n}',
      },
    ],
  },
};

export default function DocsScreen() {
  const theme = useTheme();
  const [selectedLang, setSelectedLang] = useState('javascript');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['Variables', 'Functions']));

  const docs = BUNDLED_DOCS[selectedLang] ?? { sections: [] };

  const filteredSections = docs.sections.filter(
    (s) =>
      !searchQuery ||
      s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleSection = (title: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev);
      if (next.has(title)) next.delete(title);
      else next.add(title);
      return next;
    });
  };

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: theme.colors.background }]}
    >
      {/* Header */}
      <View
        style={[
          styles.header,
          { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: theme.colors.text }]}>Docs</Text>
        <View style={[styles.offlineBadge, { backgroundColor: '#d2992222' }]}>
          <Text style={styles.offlineBadgeText}>📦 Bundled Basics</Text>
        </View>
      </View>

      {/* Language tabs */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={[styles.langTabs, { borderBottomColor: theme.colors.border }]}
        contentContainerStyle={styles.langTabsContent}
      >
        {SUPPORTED_LANGS.map((lang) => (
          <TouchableOpacity
            key={lang.id}
            onPress={() => setSelectedLang(lang.id)}
            style={[
              styles.langTab,
              selectedLang === lang.id && {
                borderBottomColor: theme.colors.accent,
                borderBottomWidth: 2,
              },
            ]}
          >
            <Text style={styles.langEmoji}>{lang.emoji}</Text>
            <Text
              style={[
                styles.langLabel,
                {
                  color:
                    selectedLang === lang.id ? theme.colors.accent : theme.colors.muted,
                },
              ]}
            >
              {lang.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Search */}
      <View style={styles.searchContainer}>
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder={`Search ${selectedLang} docs...`}
        />
      </View>

      {/* Docs content */}
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        {filteredSections.length === 0 ? (
          <View style={styles.noResults}>
            <Text style={[styles.noResultsText, { color: theme.colors.muted }]}>
              No results for "{searchQuery}"
            </Text>
          </View>
        ) : (
          filteredSections.map((section) => (
            <View
              key={section.title}
              style={[
                styles.section,
                { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
              ]}
            >
              <TouchableOpacity
                onPress={() => toggleSection(section.title)}
                style={styles.sectionHeader}
              >
                <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
                  {section.title}
                </Text>
                <Text style={[styles.sectionChevron, { color: theme.colors.muted }]}>
                  {expandedSections.has(section.title) ? '▾' : '▸'}
                </Text>
              </TouchableOpacity>

              {expandedSections.has(section.title) && (
                <View
                  style={[
                    styles.codeBlock,
                    { backgroundColor: theme.colors.terminal },
                  ]}
                >
                  <Text
                    style={[
                      styles.codeText,
                      {
                        color: theme.colors.text,
                        fontFamily: 'JetBrainsMono-Regular',
                      },
                    ]}
                  >
                    {section.content}
                  </Text>
                </View>
              )}
            </View>
          ))
        )}

        {!BUNDLED_DOCS[selectedLang] && (
          <View style={styles.noDocsBanner}>
            <Text style={[styles.noDocsText, { color: theme.colors.muted }]}>
              Basic docs for {selectedLang} are not yet bundled.{'\n'}
              Full documentation download coming soon.
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    gap: 10,
  },
  headerTitle: { fontSize: 20, fontWeight: '700', flex: 1 },
  offlineBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  offlineBadgeText: { color: '#d29922', fontSize: 11, fontWeight: '600' },
  langTabs: {
    borderBottomWidth: 1,
    maxHeight: 48,
  },
  langTabsContent: {
    paddingHorizontal: 8,
    flexDirection: 'row',
    alignItems: 'stretch',
  },
  langTab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 10,
    gap: 4,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  langEmoji: { fontSize: 12 },
  langLabel: { fontSize: 12, fontWeight: '600' },
  searchContainer: { padding: 10 },
  scroll: { flex: 1 },
  content: { padding: 10, gap: 8, paddingBottom: 40 },
  section: {
    borderRadius: 8,
    borderWidth: 1,
    overflow: 'hidden',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
  },
  sectionTitle: { flex: 1, fontSize: 14, fontWeight: '600' },
  sectionChevron: { fontSize: 12 },
  codeBlock: {
    padding: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: '#30363d',
  },
  codeText: { fontSize: 11, lineHeight: 18 },
  noResults: { padding: 24, alignItems: 'center' },
  noResultsText: { fontSize: 14 },
  noDocsBanner: { padding: 20, alignItems: 'center' },
  noDocsText: { textAlign: 'center', lineHeight: 20, fontSize: 13 },
});
