/**
 * Encodes a string to base64 for use with WebView data URIs.
 * Uses btoa with Unicode safe encoding.
 */
export function encodeHtmlToBase64(html: string): string {
  try {
    // Handle Unicode characters safely
    const bytes = encodeURIComponent(html).replace(
      /%([0-9A-F]{2})/g,
      (_match, p1: string) => String.fromCharCode(parseInt(p1, 16))
    );
    return btoa(bytes);
  } catch {
    return btoa(html);
  }
}

export function buildPreviewHtml(
  htmlContent: string,
  cssContent: string,
  jsContent: string
): string {
  const errorHandler = `
    <script>
      window.onerror = function(msg, src, line, col, err) {
        window.ReactNativeWebView && window.ReactNativeWebView.postMessage(
          JSON.stringify({ type: 'error', message: msg, line: line, col: col })
        );
        return true;
      };
      window.addEventListener('unhandledrejection', function(e) {
        window.ReactNativeWebView && window.ReactNativeWebView.postMessage(
          JSON.stringify({ type: 'error', message: e.reason?.message || String(e.reason) })
        );
      });
    </script>
  `;

  if (htmlContent) {
    // Full HTML document — inject error handler and CSS/JS if provided
    let result = htmlContent;
    if (cssContent && !htmlContent.includes('<style>')) {
      result = result.replace('</head>', `<style>${cssContent}</style></head>`);
    }
    if (!result.includes('<head>')) {
      result = `<html><head>${errorHandler}</head><body>${result}</body></html>`;
    } else {
      result = result.replace('<head>', `<head>${errorHandler}`);
    }
    return result;
  }

  // CSS-only
  if (cssContent && !jsContent) {
    return `<!DOCTYPE html>
<html>
<head>
${errorHandler}
<style>${cssContent}</style>
</head>
<body>
  <div class="preview-placeholder" style="padding:20px;font-family:sans-serif;color:#666;">
    CSS Preview — Add HTML to see styled elements
  </div>
</body>
</html>`;
  }

  // JS-only or combined
  return `<!DOCTYPE html>
<html>
<head>
${errorHandler}
<style>${cssContent}</style>
</head>
<body>
<script>${jsContent}</script>
</body>
</html>`;
}
