const EXTENSION_MAP: Record<string, string> = {
  // Web
  html: 'html',
  htm: 'html',
  css: 'css',
  scss: 'css',
  less: 'css',
  js: 'javascript',
  jsx: 'javascript',
  mjs: 'javascript',
  cjs: 'javascript',
  ts: 'typescript',
  tsx: 'typescript',
  // General-purpose
  py: 'python',
  pyw: 'python',
  c: 'c',
  h: 'c',
  cpp: 'cpp',
  cc: 'cpp',
  cxx: 'cpp',
  hpp: 'cpp',
  hxx: 'cpp',
  java: 'java',
  kt: 'kotlin',
  kts: 'kotlin',
  go: 'go',
  rs: 'rust',
  php: 'php',
  phtml: 'php',
  rb: 'ruby',
  sh: 'bash',
  bash: 'bash',
  zsh: 'bash',
  lua: 'lua',
  cs: 'csharp',
  dart: 'dart',
  swift: 'swift',
  r: 'r',
  scala: 'scala',
  hs: 'haskell',
  ex: 'elixir',
  exs: 'elixir',
  jl: 'julia',
  pl: 'perl',
  // Data / Config
  json: 'json',
  yaml: 'yaml',
  yml: 'yaml',
  toml: 'toml',
  xml: 'xml',
  md: 'markdown',
  sql: 'sql',
};

export function detectLanguageFromExtension(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() ?? '';
  return EXTENSION_MAP[ext] ?? 'plaintext';
}

export function getFileExtension(filename: string): string {
  return filename.split('.').pop()?.toLowerCase() ?? '';
}

export function getFileIcon(language: string): { icon: string; color: string } {
  const icons: Record<string, { icon: string; color: string }> = {
    html: { icon: 'code-tags', color: '#e34c26' },
    css: { icon: 'language-css3', color: '#264de4' },
    javascript: { icon: 'language-javascript', color: '#f7df1e' },
    typescript: { icon: 'language-typescript', color: '#3178c6' },
    python: { icon: 'language-python', color: '#3572a5' },
    c: { icon: 'language-c', color: '#a8b9cc' },
    cpp: { icon: 'language-cpp', color: '#9c033a' },
    java: { icon: 'language-java', color: '#b07219' },
    kotlin: { icon: 'language-kotlin', color: '#7f52ff' },
    go: { icon: 'language-go', color: '#00add8' },
    rust: { icon: 'language-rust', color: '#dea584' },
    php: { icon: 'language-php', color: '#4f5d95' },
    ruby: { icon: 'language-ruby', color: '#701516' },
    bash: { icon: 'console', color: '#89e051' },
    lua: { icon: 'code-braces', color: '#000080' },
    csharp: { icon: 'language-csharp', color: '#178600' },
    dart: { icon: 'language-dart', color: '#00b4ab' },
    swift: { icon: 'language-swift', color: '#f05138' },
    json: { icon: 'code-json', color: '#9b9b9b' },
    markdown: { icon: 'language-markdown', color: '#083fa1' },
  };
  return icons[language] ?? { icon: 'file-code', color: '#8b949e' };
}
