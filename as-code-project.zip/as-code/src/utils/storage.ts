import AsyncStorage from '@react-native-async-storage/async-storage';

export async function storageGet<T>(key: string): Promise<T | null> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (raw === null) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export async function storageSet<T>(key: string, value: T): Promise<boolean> {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export async function storageRemove(key: string): Promise<boolean> {
  try {
    await AsyncStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}

export async function storageGetAllKeys(): Promise<readonly string[]> {
  try {
    return await AsyncStorage.getAllKeys();
  } catch {
    return [];
  }
}

export const STORAGE_KEYS = {
  USER_SNIPPETS: 'user_snippets',
  BOOKMARKED_DOCS: 'bookmarked_docs',
  DOWNLOADED_DOCS: 'downloaded_docs',
  LAST_PROJECT: 'last_project',
  SETTINGS: 'settings',
  EDITOR_STATE: 'editor_state',
  GIT_PAT: 'git_pat', // Note: use expo-secure-store for this instead
} as const;
