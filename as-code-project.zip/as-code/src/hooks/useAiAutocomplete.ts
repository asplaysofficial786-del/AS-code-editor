import { useRef, useCallback } from 'react';
import { streamAutocomplete } from '../services/claudeService';
import { useEditorStore } from '../store/editorStore';
import { useSettingsStore } from '../store/settingsStore';
import { debounce } from '../utils/debounce';
import { APP_CONFIG } from '../config/appConfig';

const RETRY_DELAY_MS = 5_000;

export function useAiAutocomplete() {
  const abortRef = useRef<AbortController | null>(null);
  const retryTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const suggestionBufferRef = useRef('');
  const isRateLimitedRef = useRef(false);

  const { setAiSuggestion, setAiLoading, clearAiSuggestion, code, language } =
    useEditorStore();
  const { aiAutocompleteEnabled, aiTriggerMode } = useSettingsStore();

  const cancelPending = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    if (retryTimeoutRef.current) {
      clearTimeout(retryTimeoutRef.current);
      retryTimeoutRef.current = null;
    }
    suggestionBufferRef.current = '';
    clearAiSuggestion();
  }, [clearAiSuggestion]);

  const triggerCompletion = useCallback(
    async (contextCode: string, contextLanguage: string) => {
      if (!aiAutocompleteEnabled) return;
      if (!contextCode.trim()) return;
      if (isRateLimitedRef.current) return;

      // Cancel any in-flight request
      cancelPending();

      const controller = new AbortController();
      abortRef.current = controller;
      suggestionBufferRef.current = '';

      setAiLoading(true);

      // Take last N lines as context to keep prompt small
      const lines = contextCode.split('\n');
      const contextLines = lines
        .slice(-APP_CONFIG.ai.maxContextLines)
        .join('\n');

      await streamAutocomplete({
        code: contextLines,
        language: contextLanguage,
        abortController: controller,
        onToken: (token) => {
          suggestionBufferRef.current += token;
          setAiSuggestion(suggestionBufferRef.current);
          setAiLoading(false);
        },
        onDone: () => {
          setAiLoading(false);
        },
        onError: (err) => {
          setAiLoading(false);

          if (err.message === 'RATE_LIMIT') {
            isRateLimitedRef.current = true;
            retryTimeoutRef.current = setTimeout(() => {
              isRateLimitedRef.current = false;
              // Silently re-enable — no toast
            }, RETRY_DELAY_MS);
          }
          // All other errors: fail silently (autocomplete is non-critical)
          clearAiSuggestion();
        },
      });
    },
    [
      aiAutocompleteEnabled,
      cancelPending,
      clearAiSuggestion,
      setAiLoading,
      setAiSuggestion,
    ]
  );

  const { debounced: debouncedTrigger } = useRef(
    debounce(triggerCompletion, APP_CONFIG.ai.debounceMs)
  ).current;

  const onCodeChange = useCallback(
    (newCode: string, lang: string) => {
      if (aiTriggerMode === 'as-you-type') {
        debouncedTrigger(newCode, lang);
      }
    },
    [aiTriggerMode, debouncedTrigger]
  );

  const triggerManual = useCallback(() => {
    triggerCompletion(code, language);
  }, [code, language, triggerCompletion]);

  const acceptSuggestion = useCallback((): string => {
    const suggestion = suggestionBufferRef.current;
    cancelPending();
    return suggestion;
  }, [cancelPending]);

  const dismissSuggestion = useCallback(() => {
    cancelPending();
  }, [cancelPending]);

  return {
    onCodeChange,
    triggerManual,
    acceptSuggestion,
    dismissSuggestion,
  };
}
