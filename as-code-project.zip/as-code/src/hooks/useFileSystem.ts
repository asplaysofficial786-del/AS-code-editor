import { useCallback } from 'react';
import { useFileStore } from '../store/fileStore';
import {
  readFile,
  writeFile,
  createFile,
  createFolder,
  renameFile,
  deleteFile,
  buildFileTree,
  listProjects,
  createProject,
  deleteProject,
} from '../services/fileSystemService';
import { detectLanguageFromExtension } from '../utils/languageDetect';
import * as FileSystem from 'expo-file-system';

const PROJECTS_DIR = FileSystem.documentDirectory + 'projects/';

export function useFileSystem() {
  const {
    openFile,
    closeTab,
    setFileTree,
    setCurrentProject,
    setProjects,
    updateTabContent,
    markTabSaved,
    openTabs,
    activeTabId,
  } = useFileStore();

  const openFileInEditor = useCallback(
    async (path: string, name: string) => {
      try {
        const content = await readFile(path);
        const language = detectLanguageFromExtension(name);
        openFile({ name, path, language, content });
      } catch (err) {
        console.error('Failed to open file:', err);
      }
    },
    [openFile]
  );

  const saveActiveFile = useCallback(async () => {
    const tab = openTabs.find((t) => t.id === activeTabId);
    if (!tab) return;
    try {
      await writeFile(tab.path, tab.content);
      markTabSaved(tab.id);
    } catch (err) {
      console.error('Failed to save file:', err);
    }
  }, [openTabs, activeTabId, markTabSaved]);

  const loadProject = useCallback(
    async (projectName: string) => {
      const projectPath = PROJECTS_DIR + projectName + '/';
      const tree = await buildFileTree(projectPath);
      setFileTree(tree);
      setCurrentProject(projectName, projectPath);
    },
    [setFileTree, setCurrentProject]
  );

  const refreshProjects = useCallback(async () => {
    const projects = await listProjects();
    setProjects(projects);
  }, [setProjects]);

  const newProject = useCallback(
    async (name: string) => {
      await createProject(name);
      await refreshProjects();
      await loadProject(name);
    },
    [refreshProjects, loadProject]
  );

  const removeProject = useCallback(
    async (name: string) => {
      await deleteProject(name);
      await refreshProjects();
    },
    [refreshProjects]
  );

  return {
    openFileInEditor,
    saveActiveFile,
    loadProject,
    refreshProjects,
    newProject,
    removeProject,
    createFile,
    createFolder,
    renameFile,
    deleteFile,
    buildFileTree,
  };
}
