import { THEME_REGISTRY, ThemeId } from '../themes/themeRegistry';
import { useSettingsStore } from '../store/settingsStore';

export function useTheme() {
  const { activeTheme } = useSettingsStore();
  const themeId = activeTheme as ThemeId;
  const theme = THEME_REGISTRY[themeId] ?? THEME_REGISTRY.githubDarkPro;
  return theme;
}
