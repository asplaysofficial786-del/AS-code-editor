import { useState, useCallback } from 'react';
import { executeCode, ExecutionResult } from '../services/pistonService';
import { useEditorStore } from '../store/editorStore';
import { useSettingsStore } from '../store/settingsStore';
import { APP_CONFIG } from '../config/appConfig';

export function useCodeExecution() {
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<ExecutionResult[]>([]);
  const { code, language } = useEditorStore();
  const { pistonMode, pistonSelfHostedUrl } = useSettingsStore();

  const runCode = useCallback(async () => {
    if (isRunning) return;
    setIsRunning(true);

    const customUrl =
      pistonMode === 'self-hosted' ? pistonSelfHostedUrl : undefined;

    const result = await executeCode(code, language, customUrl);

    setResults((prev) => {
      const updated = [result, ...prev];
      // Keep last N results
      return updated.slice(0, APP_CONFIG.execution.maxHistoryItems);
    });

    setIsRunning(false);
  }, [isRunning, code, language, pistonMode, pistonSelfHostedUrl]);

  const clearResults = useCallback(() => {
    setResults([]);
  }, []);

  return {
    runCode,
    isRunning,
    results,
    clearResults,
    latestResult: results[0] ?? null,
  };
}
