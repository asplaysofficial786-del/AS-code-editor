import {
  PISTON_BASE_URL,
  PISTON_LANGUAGE_MAP,
  PREVIEW_ONLY_LANGUAGES,
  EXECUTION_TIMEOUT_MS,
} from '../config/pistonConfig';

export interface ExecutionResult {
  stdout: string;
  stderr: string;
  exitCode: number | null;
  signal: string | null;
  compileStdout?: string;
  compileStderr?: string;
  compileExitCode?: number | null;
  error?: string;
  timestamp: string;
  duration?: number;
}

export async function executeCode(
  code: string,
  language: string,
  customBaseUrl?: string
): Promise<ExecutionResult> {
  const timestamp = new Date().toLocaleTimeString('en-US', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  if (PREVIEW_ONLY_LANGUAGES.has(language)) {
    return {
      stdout: '',
      stderr: 'Use the Preview tab for HTML and CSS files.',
      exitCode: 1,
      signal: null,
      timestamp,
      error: 'PREVIEW_ONLY',
    };
  }

  const langConfig = PISTON_LANGUAGE_MAP[language];
  if (!langConfig) {
    return {
      stdout: '',
      stderr: `Execution not supported for language: ${language}`,
      exitCode: 1,
      signal: null,
      timestamp,
      error: 'UNSUPPORTED_LANGUAGE',
    };
  }

  const baseUrl = customBaseUrl ?? PISTON_BASE_URL;
  const startTime = Date.now();

  try {
    const response = await fetch(`${baseUrl}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        language: langConfig.language,
        version: langConfig.version,
        files: [
          {
            name: `main.${langConfig.fileExtension}`,
            content: code,
          },
        ],
        stdin: '',
        args: [],
        compile_timeout: EXECUTION_TIMEOUT_MS,
        run_timeout: EXECUTION_TIMEOUT_MS,
        compile_memory_limit: -1,
        run_memory_limit: -1,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return {
        stdout: '',
        stderr: `Server error ${response.status}: ${errText}`,
        exitCode: 1,
        signal: null,
        timestamp,
        error: 'SERVER_ERROR',
      };
    }

    const data = (await response.json()) as {
      compile?: { stdout: string; stderr: string; code: number | null; signal: string | null };
      run: { stdout: string; stderr: string; code: number | null; signal: string | null };
    };

    const duration = Date.now() - startTime;

    // Check for SIGKILL (timeout)
    const signal = data.run.signal;
    if (signal === 'SIGKILL') {
      return {
        stdout: data.run.stdout,
        stderr: 'Execution timed out after 10 seconds.',
        exitCode: null,
        signal,
        compileStdout: data.compile?.stdout,
        compileStderr: data.compile?.stderr,
        compileExitCode: data.compile?.code,
        timestamp,
        duration,
        error: 'TIMEOUT',
      };
    }

    return {
      stdout: data.run.stdout,
      stderr: data.run.stderr,
      exitCode: data.run.code,
      signal: data.run.signal,
      compileStdout: data.compile?.stdout,
      compileStderr: data.compile?.stderr,
      compileExitCode: data.compile?.code,
      timestamp,
      duration,
    };
  } catch (err) {
    const isNetworkError =
      err instanceof TypeError && err.message.includes('Network request failed');

    return {
      stdout: '',
      stderr: isNetworkError
        ? 'No internet connection — cannot execute code.'
        : `Execution error: ${err instanceof Error ? err.message : String(err)}`,
      exitCode: 1,
      signal: null,
      timestamp,
      error: isNetworkError ? 'NETWORK_ERROR' : 'UNKNOWN_ERROR',
    };
  }
}
