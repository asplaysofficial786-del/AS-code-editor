import * as FileSystem from 'expo-file-system';
import { FileNode } from '../store/fileStore';
import { detectLanguageFromExtension } from '../utils/languageDetect';

const PROJECTS_DIR = FileSystem.documentDirectory + 'projects/';

export async function ensureProjectsDir(): Promise<void> {
  const info = await FileSystem.getInfoAsync(PROJECTS_DIR);
  if (!info.exists) {
    await FileSystem.makeDirectoryAsync(PROJECTS_DIR, { intermediates: true });
  }
}

export async function listProjects(): Promise<string[]> {
  await ensureProjectsDir();
  const result = await FileSystem.readDirectoryAsync(PROJECTS_DIR);
  return result;
}

export async function createProject(name: string): Promise<string> {
  await ensureProjectsDir();
  const projectPath = PROJECTS_DIR + name + '/';
  await FileSystem.makeDirectoryAsync(projectPath, { intermediates: true });
  // Create a default main file
  await FileSystem.writeAsStringAsync(
    projectPath + 'main.js',
    '// Welcome to ' + name + '\nconsole.log("Hello, World!");\n'
  );
  return projectPath;
}

export async function deleteProject(name: string): Promise<void> {
  const projectPath = PROJECTS_DIR + name;
  await FileSystem.deleteAsync(projectPath, { idempotent: true });
}

export async function readFile(path: string): Promise<string> {
  const info = await FileSystem.getInfoAsync(path);
  if (!info.exists) throw new Error(`File not found: ${path}`);
  return FileSystem.readAsStringAsync(path);
}

export async function writeFile(path: string, content: string): Promise<void> {
  await FileSystem.writeAsStringAsync(path, content);
}

export async function createFile(
  dirPath: string,
  fileName: string,
  content = ''
): Promise<string> {
  const fullPath = dirPath.endsWith('/') ? dirPath + fileName : dirPath + '/' + fileName;
  // Handle name conflicts
  const resolvedPath = await resolveConflict(fullPath);
  await FileSystem.writeAsStringAsync(resolvedPath, content);
  return resolvedPath;
}

export async function createFolder(
  parentPath: string,
  folderName: string
): Promise<string> {
  const fullPath = parentPath.endsWith('/')
    ? parentPath + folderName
    : parentPath + '/' + folderName;
  await FileSystem.makeDirectoryAsync(fullPath, { intermediates: true });
  return fullPath;
}

export async function renameFile(
  oldPath: string,
  newName: string
): Promise<string> {
  const dir = oldPath.substring(0, oldPath.lastIndexOf('/') + 1);
  const newPath = dir + newName;
  await FileSystem.moveAsync({ from: oldPath, to: newPath });
  return newPath;
}

export async function deleteFile(path: string): Promise<void> {
  await FileSystem.deleteAsync(path, { idempotent: true });
}

export async function duplicateFile(path: string): Promise<string> {
  const ext = path.includes('.') ? '.' + path.split('.').pop() : '';
  const base = ext ? path.slice(0, -ext.length) : path;
  const newPath = await resolveConflict(base + '_copy' + ext);
  await FileSystem.copyAsync({ from: path, to: newPath });
  return newPath;
}

async function resolveConflict(path: string): Promise<string> {
  const info = await FileSystem.getInfoAsync(path);
  if (!info.exists) return path;

  const lastDot = path.lastIndexOf('.');
  const base = lastDot > 0 ? path.slice(0, lastDot) : path;
  const ext = lastDot > 0 ? path.slice(lastDot) : '';

  let counter = 1;
  let candidate = `${base} (${counter})${ext}`;
  while ((await FileSystem.getInfoAsync(candidate)).exists) {
    counter++;
    candidate = `${base} (${counter})${ext}`;
  }
  return candidate;
}

export async function buildFileTree(dirPath: string): Promise<FileNode[]> {
  const entries = await FileSystem.readDirectoryAsync(dirPath);
  const nodes: FileNode[] = [];

  for (const entry of entries.sort()) {
    const entryPath = dirPath.endsWith('/') ? dirPath + entry : dirPath + '/' + entry;
    const info = await FileSystem.getInfoAsync(entryPath);

    if (info.isDirectory) {
      nodes.push({
        id: entryPath,
        name: entry,
        path: entryPath,
        type: 'folder',
        isExpanded: false,
        children: [], // Lazy load
      });
    } else {
      const language = detectLanguageFromExtension(entry);
      nodes.push({
        id: entryPath,
        name: entry,
        path: entryPath,
        type: 'file',
        language,
      });
    }
  }

  return nodes;
}
