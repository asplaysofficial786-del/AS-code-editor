import * as git from 'isomorphic-git';
import http from '@isomorphic-git/http';
import * as FileSystem from 'expo-file-system';
import * as SecureStore from 'expo-secure-store';

const fs = {
  promises: {
    readFile: async (path: string, options?: { encoding?: string }) => {
      const content = await FileSystem.readAsStringAsync(path, {
        encoding: options?.encoding === 'utf8'
          ? FileSystem.EncodingType.UTF8
          : FileSystem.EncodingType.Base64,
      });
      return options?.encoding === 'utf8' ? content : Buffer.from(content, 'base64');
    },
    writeFile: async (path: string, data: string | Uint8Array) => {
      const content = typeof data === 'string' ? data : Buffer.from(data).toString('utf8');
      await FileSystem.writeAsStringAsync(path, content);
    },
    unlink: (path: string) => FileSystem.deleteAsync(path, { idempotent: true }),
    readdir: (path: string) => FileSystem.readDirectoryAsync(path),
    mkdir: (path: string) => FileSystem.makeDirectoryAsync(path, { intermediates: true }),
    rmdir: (path: string) => FileSystem.deleteAsync(path, { idempotent: true }),
    stat: async (path: string) => {
      const info = await FileSystem.getInfoAsync(path);
      if (!info.exists) throw new Error(`ENOENT: ${path}`);
      return {
        isFile: () => !info.isDirectory,
        isDirectory: () => !!info.isDirectory,
        isSymbolicLink: () => false,
        size: info.size ?? 0,
        mtimeMs: info.modificationTime ? info.modificationTime * 1000 : Date.now(),
        ctimeMs: Date.now(),
        mode: 0o644,
      };
    },
    lstat: async (path: string) => {
      const info = await FileSystem.getInfoAsync(path);
      if (!info.exists) throw new Error(`ENOENT: ${path}`);
      return {
        isFile: () => !info.isDirectory,
        isDirectory: () => !!info.isDirectory,
        isSymbolicLink: () => false,
        size: info.size ?? 0,
        mtimeMs: info.modificationTime ? info.modificationTime * 1000 : Date.now(),
        ctimeMs: Date.now(),
        mode: 0o644,
      };
    },
  },
};

const PAT_STORE_KEY = 'git_personal_access_token';

export async function storePAT(token: string): Promise<void> {
  await SecureStore.setItemAsync(PAT_STORE_KEY, token);
}

export async function getPAT(): Promise<string | null> {
  return SecureStore.getItemAsync(PAT_STORE_KEY);
}

export async function clearPAT(): Promise<void> {
  await SecureStore.deleteItemAsync(PAT_STORE_KEY);
}

function getAuth(url: string) {
  return async () => {
    const token = await getPAT();
    if (!token) throw new Error('No PAT stored. Please authenticate first.');
    return { username: token, password: 'x-oauth-basic' };
  };
}

export interface GitStatusEntry {
  filepath: string;
  status: string;
  statusLabel: string;
  color: string;
}

export async function gitInit(dir: string): Promise<void> {
  await git.init({ fs, dir });
}

export async function gitStatus(dir: string): Promise<GitStatusEntry[]> {
  const matrix = await git.statusMatrix({ fs, dir });
  return matrix
    .filter(([, head, workdir, stage]) => !(head === 1 && workdir === 1 && stage === 1))
    .map(([filepath, head, workdir, stage]) => {
      let status = 'unmodified';
      let statusLabel = '';
      let color = '#8b949e';

      if (head === 0 && workdir === 2 && stage === 0) {
        status = 'untracked'; statusLabel = 'U'; color = '#3fb950';
      } else if (head === 0 && workdir === 2 && stage === 2) {
        status = 'added'; statusLabel = 'A'; color = '#3fb950';
      } else if (head === 1 && workdir === 2 && stage === 1) {
        status = 'modified'; statusLabel = 'M'; color = '#d29922';
      } else if (head === 1 && workdir === 2 && stage === 2) {
        status = 'staged'; statusLabel = 'S'; color = '#58a6ff';
      } else if (head === 1 && workdir === 0 && stage === 1) {
        status = 'deleted'; statusLabel = 'D'; color = '#f85149';
      }

      return { filepath: String(filepath), status, statusLabel, color };
    });
}

export async function gitAdd(dir: string, filepath: string): Promise<void> {
  await git.add({ fs, dir, filepath });
}

export async function gitAddAll(dir: string): Promise<void> {
  const status = await gitStatus(dir);
  for (const entry of status) {
    if (entry.status !== 'deleted') {
      await git.add({ fs, dir, filepath: entry.filepath });
    }
  }
}

export async function gitCommit(
  dir: string,
  message: string,
  authorName = 'AS Code User',
  authorEmail = 'user@ascode.app'
): Promise<string> {
  const sha = await git.commit({
    fs,
    dir,
    message,
    author: { name: authorName, email: authorEmail },
  });
  return sha;
}

export async function gitClone(
  url: string,
  dir: string,
  onProgress?: (stage: string, loaded: number, total: number) => void
): Promise<void> {
  await git.clone({
    fs,
    http,
    dir,
    url,
    singleBranch: true,
    depth: 1,
    onAuth: getAuth(url),
    onProgress: onProgress
      ? (evt) => onProgress(evt.phase, evt.loaded, evt.total ?? 0)
      : undefined,
  });
}

export async function gitPull(dir: string, url: string): Promise<void> {
  await git.pull({
    fs,
    http,
    dir,
    url,
    singleBranch: true,
    onAuth: getAuth(url),
    author: { name: 'AS Code User', email: 'user@ascode.app' },
  });
}

export async function gitPush(dir: string, url: string): Promise<void> {
  await git.push({
    fs,
    http,
    dir,
    url,
    onAuth: getAuth(url),
  });
}

export interface GitLogEntry {
  oid: string;
  message: string;
  author: string;
  date: Date;
}

export async function gitLog(dir: string, depth = 20): Promise<GitLogEntry[]> {
  const commits = await git.log({ fs, dir, depth });
  return commits.map((c) => ({
    oid: c.oid.slice(0, 7),
    message: c.commit.message.trim(),
    author: c.commit.author.name,
    date: new Date(c.commit.author.timestamp * 1000),
  }));
}

export async function gitCurrentBranch(dir: string): Promise<string> {
  const branch = await git.currentBranch({ fs, dir });
  return branch ?? 'HEAD';
}
