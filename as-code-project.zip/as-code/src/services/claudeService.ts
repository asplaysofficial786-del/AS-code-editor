import {
  CLAUDE_API_KEY,
  CLAUDE_API_BASE_URL,
  CLAUDE_API_VERSION,
  CLAUDE_MODEL,
  CLAUDE_MAX_TOKENS,
  CLAUDE_SYSTEM_PROMPT,
} from '../config/apiKeys';

export interface ClaudeStreamOptions {
  code: string;
  language: string;
  abortController?: AbortController;
  onToken: (token: string) => void;
  onDone: () => void;
  onError: (err: Error) => void;
}

/**
 * Streams a code autocomplete suggestion from the Claude API.
 * Parses SSE (Server-Sent Events) chunks and fires `onToken` for each delta.
 */
export async function streamAutocomplete(options: ClaudeStreamOptions): Promise<void> {
  const { code, language, abortController, onToken, onDone, onError } = options;

  if (!CLAUDE_API_KEY) {
    onError(new Error('No Claude API key configured. Add it to src/config/apiKeys.ts'));
    return;
  }

  const prompt = `Language: ${language}\n\n${code}`;

  try {
    const response = await fetch(CLAUDE_API_BASE_URL, {
      method: 'POST',
      signal: abortController?.signal,
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CLAUDE_API_KEY,
        'anthropic-version': CLAUDE_API_VERSION,
        'anthropic-beta': 'messages-2023-12-15',
      },
      body: JSON.stringify({
        model: CLAUDE_MODEL,
        max_tokens: CLAUDE_MAX_TOKENS,
        stream: true,
        system: CLAUDE_SYSTEM_PROMPT,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        throw new Error('RATE_LIMIT');
      }
      throw new Error(`API error: ${response.status}`);
    }

    const reader = response.body?.getReader();
    if (!reader) throw new Error('No response body');

    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const data = line.slice(6).trim();
        if (data === '[DONE]') {
          onDone();
          return;
        }

        try {
          const parsed = JSON.parse(data) as {
            type: string;
            delta?: { type: string; text?: string };
          };
          if (
            parsed.type === 'content_block_delta' &&
            parsed.delta?.type === 'text_delta' &&
            parsed.delta.text
          ) {
            onToken(parsed.delta.text);
          }
        } catch {
          // Malformed JSON chunk — skip silently
        }
      }
    }

    onDone();
  } catch (err) {
    if (err instanceof Error && err.name === 'AbortError') {
      // Intentional cancel — do nothing
      return;
    }
    onError(err instanceof Error ? err : new Error(String(err)));
  }
}

/**
 * Format code via Claude for languages Prettier doesn't support.
 */
export async function formatCodeWithClaude(
  code: string,
  language: string
): Promise<string> {
  if (!CLAUDE_API_KEY) return code;

  const response = await fetch(CLAUDE_API_BASE_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': CLAUDE_API_KEY,
      'anthropic-version': CLAUDE_API_VERSION,
    },
    body: JSON.stringify({
      model: CLAUDE_MODEL,
      max_tokens: 4096,
      system:
        'You are a code formatter. Reformat and clean up the provided code. ' +
        'Return ONLY the reformatted code, no explanations, no markdown, no backticks.',
      messages: [
        {
          role: 'user',
          content: `Language: ${language}\n\n${code}`,
        },
      ],
    }),
  });

  if (!response.ok) throw new Error(`Format API error: ${response.status}`);

  const data = (await response.json()) as {
    content: Array<{ type: string; text?: string }>;
  };

  return (
    data.content
      .filter((b) => b.type === 'text')
      .map((b) => b.text ?? '')
      .join('') || code
  );
}
