import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import EditorScreen from '../screens/EditorScreen';
import ExplorerScreen from '../screens/ExplorerScreen';
import ExtensionsScreen from '../screens/ExtensionsScreen';
import DocsScreen from '../screens/DocsScreen';
import SettingsScreen from '../screens/SettingsScreen';
import { useTheme } from '../hooks/useTheme';

export type RootTabParamList = {
  Editor: undefined;
  Explorer: undefined;
  Extensions: undefined;
  Docs: undefined;
  Settings: undefined;
};

const Tab = createBottomTabNavigator<RootTabParamList>();

interface TabIconProps {
  label: string;
  emoji: string;
  focused: boolean;
  color: string;
}

function TabIcon({ emoji, label, focused, color }: TabIconProps) {
  return (
    <View style={styles.tabIconContainer}>
      <Text style={[styles.tabEmoji, focused && { transform: [{ scale: 1.15 }] }]}>
        {emoji}
      </Text>
    </View>
  );
}

export default function AppNavigator() {
  const theme = useTheme();

  return (
    <NavigationContainer
      theme={{
        dark: theme.isDark,
        colors: {
          primary: theme.colors.accent,
          background: theme.colors.background,
          card: theme.colors.surface,
          text: theme.colors.text,
          border: theme.colors.border,
          notification: theme.colors.accent,
        },
      }}
    >
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarShowLabel: false,
          tabBarStyle: {
            backgroundColor: theme.colors.surface,
            borderTopColor: theme.colors.border,
            borderTopWidth: 1,
            height: 56,
            paddingBottom: 4,
            paddingTop: 4,
          },
          tabBarActiveTintColor: theme.colors.accent,
          tabBarInactiveTintColor: theme.colors.muted,
        }}
      >
        <Tab.Screen
          name="Editor"
          component={EditorScreen}
          options={{
            tabBarIcon: ({ focused, color }) => (
              <TabIcon emoji="📝" label="Editor" focused={focused} color={color} />
            ),
          }}
        />
        <Tab.Screen
          name="Explorer"
          component={ExplorerScreen}
          options={{
            tabBarIcon: ({ focused, color }) => (
              <TabIcon emoji="📁" label="Explorer" focused={focused} color={color} />
            ),
          }}
        />
        <Tab.Screen
          name="Extensions"
          component={ExtensionsScreen}
          options={{
            tabBarIcon: ({ focused, color }) => (
              <TabIcon emoji="🔌" label="Extensions" focused={focused} color={color} />
            ),
          }}
        />
        <Tab.Screen
          name="Docs"
          component={DocsScreen}
          options={{
            tabBarIcon: ({ focused, color }) => (
              <TabIcon emoji="📖" label="Docs" focused={focused} color={color} />
            ),
          }}
        />
        <Tab.Screen
          name="Settings"
          component={SettingsScreen}
          options={{
            tabBarIcon: ({ focused, color }) => (
              <TabIcon emoji="⚙️" label="Settings" focused={focused} color={color} />
            ),
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  tabIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 40,
    height: 40,
  },
  tabEmoji: {
    fontSize: 22,
  },
});
