/**
 * API Keys Configuration
 * These values are loaded from environment variables at build time.
 * NEVER commit real API keys to version control.
 *
 * To set your Claude API key:
 * 1. Create a .env file in the project root (it is gitignored)
 * 2. Add: EXPO_PUBLIC_CLAUDE_API_KEY=sk-ant-your-key-here
 */

export const CLAUDE_API_KEY: string =
  process.env.EXPO_PUBLIC_CLAUDE_API_KEY ?? '';

export const CLAUDE_API_BASE_URL = 'https://api.anthropic.com/v1/messages';
export const CLAUDE_API_VERSION = '2023-06-01';
export const CLAUDE_MODEL = 'claude-sonnet-4-20250514';
export const CLAUDE_MAX_TOKENS = 300;

export const CLAUDE_SYSTEM_PROMPT =
  'You are a code autocomplete engine. Given the code context, output ONLY ' +
  'the next logical code continuation. No explanations. No markdown. ' +
  'No backticks. Raw code only. Match the indentation of the context exactly.';
