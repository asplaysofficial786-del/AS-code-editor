/**
 * Piston API Configuration
 * Switch between public (free, no auth) and self-hosted instance.
 *
 * To use self-hosted: set PISTON_MODE to 'self-hosted' and
 * add EXPO_PUBLIC_PISTON_SELF_HOSTED_URL to your .env file.
 */

export const PISTON_MODE: 'public' | 'self-hosted' = 'public';

export const PISTON_URLS = {
  public: 'https://emkc.org/api/v2/piston',
  selfHosted:
    process.env.EXPO_PUBLIC_PISTON_SELF_HOSTED_URL ?? 'http://localhost:2000/api/v2',
} as const;

export const PISTON_BASE_URL: string =
  PISTON_MODE === 'self-hosted' ? PISTON_URLS.selfHosted : PISTON_URLS.public;

export interface PistonLanguageConfig {
  language: string;
  version: string;
  fileExtension: string;
}

export const PISTON_LANGUAGE_MAP: Record<string, PistonLanguageConfig> = {
  python: { language: 'python', version: '3.10.0', fileExtension: 'py' },
  javascript: { language: 'javascript', version: '18.15.0', fileExtension: 'js' },
  typescript: { language: 'typescript', version: '5.0.3', fileExtension: 'ts' },
  c: { language: 'c', version: '10.2.0', fileExtension: 'c' },
  cpp: { language: 'c++', version: '10.2.0', fileExtension: 'cpp' },
  java: { language: 'java', version: '15.0.2', fileExtension: 'java' },
  kotlin: { language: 'kotlin', version: '1.8.20', fileExtension: 'kt' },
  go: { language: 'go', version: '1.16.2', fileExtension: 'go' },
  rust: { language: 'rust', version: '1.50.0', fileExtension: 'rs' },
  php: { language: 'php', version: '8.2.3', fileExtension: 'php' },
  ruby: { language: 'ruby', version: '3.0.1', fileExtension: 'rb' },
  bash: { language: 'bash', version: '5.1.0', fileExtension: 'sh' },
  lua: { language: 'lua', version: '5.4.4', fileExtension: 'lua' },
  csharp: { language: 'csharp', version: '6.12.0', fileExtension: 'cs' },
  dart: { language: 'dart', version: '2.19.6', fileExtension: 'dart' },
  swift: { language: 'swift', version: '5.3.3', fileExtension: 'swift' },
  r: { language: 'r', version: '4.1.1', fileExtension: 'r' },
  scala: { language: 'scala', version: '3.2.2', fileExtension: 'scala' },
  haskell: { language: 'haskell', version: '9.0.1', fileExtension: 'hs' },
  elixir: { language: 'elixir', version: '1.11.3', fileExtension: 'ex' },
  julia: { language: 'julia', version: '1.8.5', fileExtension: 'jl' },
  perl: { language: 'perl', version: '5.36.0', fileExtension: 'pl' },
};

export const EXECUTION_TIMEOUT_MS = 10_000;

/** Languages that use WebView preview instead of Piston execution */
export const PREVIEW_ONLY_LANGUAGES = new Set(['html', 'css']);

/** Languages with both Piston execution AND WebView preview */
export const PREVIEW_AND_RUN_LANGUAGES = new Set(['javascript']);
