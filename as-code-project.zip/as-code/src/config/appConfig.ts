export const APP_CONFIG = {
  name: 'AS Code',
  version: '1.0.0',
  buildDate: '2025',

  editor: {
    fontSize: 14,
    tabSize: 2,
    lineNumbers: true,
    autoCloseBrackets: true,
    autoCloseQuotes: true,
    autoIndent: true,
    wordWrap: false,
    minimap: false,
    scrollBeyondLastLine: false,
    maxOpenTabs: 10,
    autoSaveIntervalMs: 30_000,
  },

  ai: {
    debounceMs: 600,
    maxContextLines: 80,
    maxRetries: 1,
    retryDelayMs: 5_000,
  },

  preview: {
    debounceMs: 800,
    autoRefresh: true,
  },

  docs: {
    baseUrl:
      'https://raw.githubusercontent.com/your-org/as-code-docs/main/docs',
  },

  execution: {
    maxHistoryItems: 10,
  },

  filesystem: {
    projectsDir: 'projects/',
    docsDir: 'docs/',
    maxFilenameLength: 255,
  },
} as const;
