import React, { useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import { FileNode } from '../../store/fileStore';
import { getFileIcon } from '../../utils/languageDetect';
import { useTheme } from '../../hooks/useTheme';

interface FileTreeProps {
  nodes: FileNode[];
  onFilePress: (node: FileNode) => void;
  onFileLongPress: (node: FileNode) => void;
  onToggleFolder: (nodeId: string) => void;
  depth?: number;
}

export default function FileTree({
  nodes,
  onFilePress,
  onFileLongPress,
  onToggleFolder,
  depth = 0,
}: FileTreeProps) {
  const theme = useTheme();

  const renderItem = useCallback(
    ({ item }: { item: FileNode }) => (
      <FileItem
        node={item}
        depth={depth}
        onFilePress={onFilePress}
        onFileLongPress={onFileLongPress}
        onToggleFolder={onToggleFolder}
        theme={theme}
      />
    ),
    [depth, onFilePress, onFileLongPress, onToggleFolder, theme]
  );

  return (
    <FlatList
      data={nodes}
      keyExtractor={(item) => item.id}
      renderItem={renderItem}
      scrollEnabled={false}
      removeClippedSubviews={false}
    />
  );
}

interface FileItemProps {
  node: FileNode;
  depth: number;
  onFilePress: (node: FileNode) => void;
  onFileLongPress: (node: FileNode) => void;
  onToggleFolder: (nodeId: string) => void;
  theme: ReturnType<typeof useTheme>;
}

function FileItem({
  node,
  depth,
  onFilePress,
  onFileLongPress,
  onToggleFolder,
  theme,
}: FileItemProps) {
  const isFolder = node.type === 'folder';
  const iconData = isFolder
    ? { icon: node.isExpanded ? '📂' : '📁', color: '#d29922' }
    : getFileIconEmoji(node.language ?? 'plaintext');

  const handlePress = () => {
    if (isFolder) {
      onToggleFolder(node.id);
    } else {
      onFilePress(node);
    }
  };

  return (
    <View>
      <TouchableOpacity
        onPress={handlePress}
        onLongPress={() => onFileLongPress(node)}
        style={[
          styles.row,
          { paddingLeft: 16 + depth * 16 },
        ]}
        activeOpacity={0.6}
      >
        <Text style={styles.icon}>{iconData.icon}</Text>
        <Text
          style={[
            styles.name,
            {
              color: isFolder ? theme.colors.text : iconData.color,
              fontFamily: 'JetBrainsMono-Regular',
            },
          ]}
          numberOfLines={1}
        >
          {node.name}
        </Text>
        {isFolder && (
          <Text style={[styles.chevron, { color: theme.colors.muted }]}>
            {node.isExpanded ? '▾' : '▸'}
          </Text>
        )}
      </TouchableOpacity>

      {isFolder && node.isExpanded && node.children && node.children.length > 0 && (
        <FileTree
          nodes={node.children}
          depth={depth + 1}
          onFilePress={onFilePress}
          onFileLongPress={onFileLongPress}
          onToggleFolder={onToggleFolder}
        />
      )}
    </View>
  );
}

function getFileIconEmoji(language: string): { icon: string; color: string } {
  const map: Record<string, { icon: string; color: string }> = {
    html: { icon: '📄', color: '#e34c26' },
    css: { icon: '🎨', color: '#264de4' },
    javascript: { icon: '📜', color: '#f7df1e' },
    typescript: { icon: '📘', color: '#3178c6' },
    python: { icon: '🐍', color: '#3572a5' },
    c: { icon: '⚙️', color: '#a8b9cc' },
    cpp: { icon: '⚙️', color: '#9c033a' },
    java: { icon: '☕', color: '#b07219' },
    kotlin: { icon: '🟣', color: '#7f52ff' },
    go: { icon: '🐹', color: '#00add8' },
    rust: { icon: '🦀', color: '#dea584' },
    json: { icon: '📋', color: '#9b9b9b' },
    markdown: { icon: '📝', color: '#083fa1' },
  };
  return map[language] ?? { icon: '📄', color: '#8b949e' };
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingRight: 12,
    gap: 6,
  },
  icon: {
    fontSize: 14,
    width: 20,
    textAlign: 'center',
  },
  name: {
    fontSize: 13,
    flex: 1,
  },
  chevron: {
    fontSize: 11,
    marginLeft: 4,
  },
});
