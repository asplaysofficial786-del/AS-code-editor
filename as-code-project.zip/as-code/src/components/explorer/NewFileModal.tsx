import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Modal,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useTheme } from '../../hooks/useTheme';

interface NewFileModalProps {
  visible: boolean;
  onClose: () => void;
  onCreate: (name: string, type: 'file' | 'folder') => void;
}

export default function NewFileModal({ visible, onClose, onCreate }: NewFileModalProps) {
  const theme = useTheme();
  const [name, setName] = useState('');
  const [type, setType] = useState<'file' | 'folder'>('file');

  const handleCreate = () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    onCreate(trimmed, type);
    setName('');
    setType('file');
    onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={onClose} />
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <View
          style={[
            styles.modal,
            { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
          ]}
        >
          <Text style={[styles.title, { color: theme.colors.text }]}>
            New {type === 'file' ? 'File' : 'Folder'}
          </Text>

          {/* Type toggle */}
          <View style={[styles.typeRow, { borderColor: theme.colors.border }]}>
            {(['file', 'folder'] as const).map((t) => (
              <TouchableOpacity
                key={t}
                onPress={() => setType(t)}
                style={[
                  styles.typeButton,
                  type === t && {
                    backgroundColor: theme.colors.accent + '22',
                    borderColor: theme.colors.accent,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.typeText,
                    { color: type === t ? theme.colors.accent : theme.colors.muted },
                  ]}
                >
                  {t === 'file' ? '📄 File' : '📁 Folder'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Name input */}
          <TextInput
            style={[
              styles.input,
              {
                color: theme.colors.text,
                backgroundColor: theme.colors.overlay,
                borderColor: theme.colors.border,
                fontFamily: 'JetBrainsMono-Regular',
              },
            ]}
            value={name}
            onChangeText={setName}
            placeholder={type === 'file' ? 'filename.py' : 'folder-name'}
            placeholderTextColor={theme.colors.muted}
            autoFocus
            autoCapitalize="none"
            autoCorrect={false}
            onSubmitEditing={handleCreate}
          />

          {/* Actions */}
          <View style={styles.actions}>
            <TouchableOpacity
              onPress={onClose}
              style={[styles.btn, { backgroundColor: theme.colors.overlay }]}
            >
              <Text style={[styles.btnText, { color: theme.colors.muted }]}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleCreate}
              disabled={!name.trim()}
              style={[
                styles.btn,
                styles.createBtn,
                { opacity: name.trim() ? 1 : 0.4 },
              ]}
            >
              <Text style={styles.createBtnText}>Create</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#00000088',
  },
  keyboardView: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modal: {
    width: '80%',
    borderRadius: 12,
    borderWidth: 1,
    padding: 20,
    gap: 14,
    elevation: 20,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
  },
  typeRow: {
    flexDirection: 'row',
    borderRadius: 8,
    borderWidth: 1,
    overflow: 'hidden',
    gap: 0,
  },
  typeButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
    borderRadius: 6,
    margin: 2,
  },
  typeText: {
    fontSize: 13,
    fontWeight: '600',
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
  },
  btn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  btnText: {
    fontSize: 14,
    fontWeight: '600',
  },
  createBtn: {
    backgroundColor: '#1a3a58',
  },
  createBtnText: {
    color: '#58a6ff',
    fontSize: 14,
    fontWeight: '700',
  },
});
