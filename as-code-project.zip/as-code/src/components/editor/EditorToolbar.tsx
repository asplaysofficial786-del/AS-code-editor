import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { useTheme } from '../../hooks/useTheme';

interface EditorToolbarProps {
  onInsert: (text: string) => void;
  onFormat: () => void;
  onAiTrigger: () => void;
  onRun: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canRun: boolean;
  isAiLoading: boolean;
}

const SYMBOL_BUTTONS = [
  { label: '{', value: '{' },
  { label: '}', value: '}' },
  { label: '(', value: '(' },
  { label: ')', value: ')' },
  { label: '[', value: '[' },
  { label: ']', value: ']' },
  { label: ';', value: ';' },
  { label: ':', value: ':' },
  { label: '"', value: '"' },
  { label: "'", value: "'" },
  { label: '=', value: '=' },
  { label: '+', value: '+' },
  { label: '-', value: '-' },
  { label: '/', value: '/' },
  { label: '*', value: '*' },
  { label: '<', value: '<' },
  { label: '>', value: '>' },
  { label: '→', value: '=>' },
  { label: '.', value: '.' },
  { label: '!', value: '!' },
  { label: '&', value: '&' },
  { label: '|', value: '|' },
  { label: '_', value: '_' },
  { label: '#', value: '#' },
  { label: '@', value: '@' },
  { label: '%', value: '%' },
  { label: 'Tab', value: '  ' },
];

export default function EditorToolbar({
  onInsert,
  onFormat,
  onAiTrigger,
  onRun,
  onUndo,
  onRedo,
  canRun,
  isAiLoading,
}: EditorToolbarProps) {
  const theme = useTheme();

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.surface, borderTopColor: theme.colors.border },
      ]}
    >
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="always"
      >
        {/* Undo / Redo */}
        <ToolbarButton
          label="↩"
          onPress={onUndo}
          bgColor={theme.colors.overlay}
          textColor={theme.colors.text}
        />
        <ToolbarButton
          label="↪"
          onPress={onRedo}
          bgColor={theme.colors.overlay}
          textColor={theme.colors.text}
        />

        <View style={[styles.divider, { backgroundColor: theme.colors.border }]} />

        {/* Symbol buttons */}
        {SYMBOL_BUTTONS.map((btn) => (
          <ToolbarButton
            key={btn.label}
            label={btn.label}
            onPress={() => onInsert(btn.value)}
            bgColor={theme.colors.overlay}
            textColor={theme.colors.text}
          />
        ))}

        <View style={[styles.divider, { backgroundColor: theme.colors.border }]} />

        {/* Format button */}
        <ToolbarButton
          label="✨ Fmt"
          onPress={onFormat}
          bgColor={theme.colors.overlay}
          textColor={theme.colors.accent}
          minWidth={52}
        />

        {/* AI trigger button */}
        <View style={styles.aiButton}>
          <TouchableOpacity
            onPress={onAiTrigger}
            style={[styles.aiTouchable, isAiLoading && styles.aiLoading]}
            activeOpacity={0.7}
          >
            <Text style={styles.aiButtonText}>
              {isAiLoading ? '⏳ AI' : '✦ AI'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Run button */}
        {canRun && (
          <ToolbarButton
            label="▶ Run"
            onPress={onRun}
            bgColor="#1a3a1a"
            textColor={theme.colors.success}
            minWidth={56}
          />
        )}
      </ScrollView>
    </View>
  );
}

interface ToolbarButtonProps {
  label: string;
  onPress: () => void;
  bgColor: string;
  textColor: string;
  minWidth?: number;
}

function ToolbarButton({ label, onPress, bgColor, textColor, minWidth = 36 }: ToolbarButtonProps) {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.button, { backgroundColor: bgColor, minWidth }]}
      activeOpacity={0.6}
    >
      <Text style={[styles.buttonText, { color: textColor }]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 44,
    borderTopWidth: 1,
  },
  scrollContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    gap: 4,
  },
  button: {
    height: 34,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 8,
  },
  buttonText: {
    fontSize: 13,
    fontFamily: 'JetBrainsMono-Regular',
    fontWeight: '500',
  },
  divider: {
    width: 1,
    height: 24,
    marginHorizontal: 4,
  },
  aiButton: {
    marginHorizontal: 2,
  },
  aiTouchable: {
    height: 34,
    borderRadius: 6,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
    // Gradient simulation via backgroundColor
    backgroundColor: '#4c1d95',
  },
  aiLoading: {
    opacity: 0.6,
  },
  aiButtonText: {
    color: '#e9d5ff',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
});
