import React, { useRef, useCallback } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  TextInput,
  Text,
} from 'react-native';
import { useTheme } from '../../hooks/useTheme';

interface CodeEditorProps {
  code: string;
  language: string;
  fontSize: number;
  onChange: (code: string) => void;
  onCursorChange?: (line: number, col: number) => void;
}

/**
 * CodeEditor component wrapping a styled TextInput for code editing.
 * In production, replace with react-native-code-editor for full syntax highlighting.
 * This implementation provides a functional, styled editor with JetBrains Mono font.
 */
export default function CodeEditor({
  code,
  language,
  fontSize,
  onChange,
  onCursorChange,
}: CodeEditorProps) {
  const theme = useTheme();
  const inputRef = useRef<TextInput>(null);
  const scrollRef = useRef<ScrollView>(null);

  const handleChange = useCallback(
    (text: string) => {
      onChange(text);
    },
    [onChange]
  );

  const handleSelectionChange = useCallback(
    (e: { nativeEvent: { selection: { start: number; end: number } } }) => {
      if (!onCursorChange) return;
      const { start } = e.nativeEvent.selection;
      const lines = code.slice(0, start).split('\n');
      const line = lines.length;
      const col = lines[lines.length - 1].length + 1;
      onCursorChange(line, col);
    },
    [code, onCursorChange]
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      {/* Line numbers */}
      <LineNumbers
        code={code}
        fontSize={fontSize}
        theme={theme}
      />

      {/* Code input */}
      <ScrollView
        ref={scrollRef}
        style={styles.scroll}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyboardShouldPersistTaps="always"
        scrollEventThrottle={16}
      >
        <TextInput
          ref={inputRef}
          style={[
            styles.input,
            {
              color: theme.colors.text,
              fontSize,
              fontFamily: 'JetBrainsMono-Regular',
              lineHeight: fontSize * 1.6,
            },
          ]}
          value={code}
          onChangeText={handleChange}
          onSelectionChange={handleSelectionChange}
          multiline
          autoCorrect={false}
          autoCapitalize="none"
          autoComplete="off"
          spellCheck={false}
          keyboardType="default"
          textAlignVertical="top"
          scrollEnabled={false}
          underlineColorAndroid="transparent"
          selectionColor={theme.colors.accent + '80'}
          cursorColor={theme.colors.accent}
        />
      </ScrollView>
    </View>
  );
}

interface LineNumbersProps {
  code: string;
  fontSize: number;
  theme: ReturnType<typeof useTheme>;
}

function LineNumbers({ code, fontSize, theme }: LineNumbersProps) {
  const lineCount = code.split('\n').length;

  return (
    <View
      style={[
        styles.lineNumbers,
        { backgroundColor: theme.colors.background, borderRightColor: theme.colors.border },
      ]}
    >
      {Array.from({ length: lineCount }, (_, i) => (
        <Text
          key={i}
          style={[
            styles.lineNumber,
            {
              color: theme.colors.muted,
              fontSize: fontSize - 2,
              lineHeight: fontSize * 1.6,
              fontFamily: 'JetBrainsMono-Regular',
            },
          ]}
        >
          {i + 1}
        </Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
  },
  lineNumbers: {
    paddingHorizontal: 8,
    paddingTop: 8,
    minWidth: 40,
    borderRightWidth: 1,
    alignItems: 'flex-end',
  },
  lineNumber: {
    textAlign: 'right',
  },
  scroll: {
    flex: 1,
  },
  input: {
    flex: 1,
    padding: 8,
    paddingTop: 8,
    minWidth: 300,
    // Disable default text styling
    textDecorationLine: 'none',
  },
});
