import React from 'react';
import {
  ScrollView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { FileTab } from '../../store/fileStore';
import { useTheme } from '../../hooks/useTheme';

interface TabBarProps {
  tabs: FileTab[];
  activeTabId: string | null;
  onTabPress: (tabId: string) => void;
  onTabClose: (tabId: string) => void;
}

export default function TabBar({
  tabs,
  activeTabId,
  onTabPress,
  onTabClose,
}: TabBarProps) {
  const theme = useTheme();

  if (tabs.length === 0) return null;

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
      ]}
    >
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          return (
            <TouchableOpacity
              key={tab.id}
              onPress={() => onTabPress(tab.id)}
              style={[
                styles.tab,
                {
                  backgroundColor: isActive ? theme.colors.background : 'transparent',
                  borderBottomColor: isActive ? theme.colors.accent : 'transparent',
                },
              ]}
              activeOpacity={0.7}
            >
              {tab.isDirty && (
                <View
                  style={[styles.dirtyDot, { backgroundColor: theme.colors.warning }]}
                />
              )}
              <Text
                style={[
                  styles.tabName,
                  {
                    color: isActive ? theme.colors.text : theme.colors.muted,
                    fontFamily: isActive ? undefined : undefined,
                  },
                ]}
                numberOfLines={1}
              >
                {tab.name}
              </Text>
              <TouchableOpacity
                onPress={() => onTabClose(tab.id)}
                style={styles.closeButton}
                hitSlop={{ top: 8, bottom: 8, left: 4, right: 4 }}
              >
                <Text style={[styles.closeText, { color: theme.colors.muted }]}>×</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 36,
    borderBottomWidth: 1,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'stretch',
  },
  tab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderBottomWidth: 2,
    maxWidth: 160,
    minWidth: 80,
    gap: 6,
  },
  dirtyDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  tabName: {
    fontSize: 12,
    flex: 1,
  },
  closeButton: {
    padding: 2,
  },
  closeText: {
    fontSize: 16,
    lineHeight: 18,
  },
});
