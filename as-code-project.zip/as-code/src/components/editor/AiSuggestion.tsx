import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../../hooks/useTheme';
import LoadingSpinner from '../common/LoadingSpinner';

interface AiSuggestionProps {
  suggestion: string;
  isLoading: boolean;
}

export default function AiSuggestion({ suggestion, isLoading }: AiSuggestionProps) {
  const theme = useTheme();

  if (isLoading && !suggestion) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.surface }]}>
        <LoadingSpinner size="small" />
        <Text style={[styles.hint, { color: theme.colors.muted }]}>
          AI thinking...
        </Text>
      </View>
    );
  }

  if (!suggestion) return null;

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.surface }]}>
      <Text style={[styles.prefix, { color: theme.colors.accent }]}>✦ </Text>
      <Text
        style={[
          styles.suggestion,
          { color: theme.colors.muted, fontFamily: 'JetBrainsMono-Regular' },
        ]}
        numberOfLines={4}
      >
        {suggestion}
      </Text>
      <View style={[styles.hint2, { borderColor: theme.colors.border }]}>
        <Text style={[styles.hintText, { color: theme.colors.muted }]}>
          Tab to accept · Esc to dismiss
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  prefix: {
    fontSize: 12,
    fontWeight: '700',
  },
  suggestion: {
    fontSize: 12,
    flex: 1,
    lineHeight: 18,
  },
  hint: {
    fontSize: 11,
    marginLeft: 6,
  },
  hint2: {
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginLeft: 'auto',
    marginTop: 2,
  },
  hintText: {
    fontSize: 10,
  },
});
