import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface BadgeProps {
  label: string;
  color?: string;
  backgroundColor?: string;
  size?: 'sm' | 'md';
}

export default function Badge({
  label,
  color = '#c9d1d9',
  backgroundColor = '#21262d',
  size = 'sm',
}: BadgeProps) {
  const fontSize = size === 'sm' ? 10 : 12;
  const paddingH = size === 'sm' ? 6 : 10;
  const paddingV = size === 'sm' ? 2 : 4;

  return (
    <View
      style={[
        styles.badge,
        { backgroundColor, paddingHorizontal: paddingH, paddingVertical: paddingV },
      ]}
    >
      <Text style={[styles.label, { color, fontSize }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    borderRadius: 4,
    alignSelf: 'flex-start',
  },
  label: {
    fontWeight: '600',
    letterSpacing: 0.3,
  },
});
