import React, { useEffect, useRef } from 'react';
import { View, Animated, Text, StyleSheet } from 'react-native';
import { useTheme } from '../../hooks/useTheme';

interface LoadingSpinnerProps {
  size?: 'small' | 'large';
  label?: string;
}

export default function LoadingSpinner({ size = 'small', label }: LoadingSpinnerProps) {
  const dot1 = useRef(new Animated.Value(0)).current;
  const dot2 = useRef(new Animated.Value(0)).current;
  const dot3 = useRef(new Animated.Value(0)).current;
  const theme = useTheme();

  useEffect(() => {
    const createPulse = (anim: Animated.Value, delay: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(anim, { toValue: 1, duration: 400, useNativeDriver: true }),
          Animated.timing(anim, { toValue: 0, duration: 400, useNativeDriver: true }),
          Animated.delay(800 - delay),
        ])
      );

    const a1 = createPulse(dot1, 0);
    const a2 = createPulse(dot2, 200);
    const a3 = createPulse(dot3, 400);

    a1.start();
    a2.start();
    a3.start();

    return () => {
      a1.stop();
      a2.stop();
      a3.stop();
    };
  }, [dot1, dot2, dot3]);

  const dotSize = size === 'large' ? 10 : 7;
  const gap = size === 'large' ? 8 : 5;

  return (
    <View style={styles.container}>
      <View style={[styles.dotsRow, { gap }]}>
        {[dot1, dot2, dot3].map((anim, i) => (
          <Animated.View
            key={i}
            style={[
              styles.dot,
              {
                width: dotSize,
                height: dotSize,
                borderRadius: dotSize / 2,
                backgroundColor: theme.colors.accent,
                opacity: anim.interpolate({ inputRange: [0, 1], outputRange: [0.25, 1] }),
                transform: [
                  {
                    scale: anim.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1.2] }),
                  },
                ],
              },
            ]}
          />
        ))}
      </View>
      {label && (
        <Text style={[styles.label, { color: theme.colors.muted }]}>{label}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: 'center' },
  dotsRow: { flexDirection: 'row', alignItems: 'center' },
  dot: {},
  label: { marginTop: 8, fontSize: 12 },
});
