import React, { useState, useCallback, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { WebView } from 'react-native-webview';
import { useTheme } from '../../hooks/useTheme';
import { encodeHtmlToBase64, buildPreviewHtml } from '../../utils/base64';

interface WebPreviewProps {
  html: string;
  css: string;
  js: string;
  language: string;
  autoRefresh: boolean;
  onToggleAutoRefresh: () => void;
}

export default function WebPreview({
  html,
  css,
  js,
  language,
  autoRefresh,
  onToggleAutoRefresh,
}: WebPreviewProps) {
  const theme = useTheme();
  const webviewRef = useRef<WebView>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [jsError, setJsError] = useState<string | null>(null);
  const [key, setKey] = useState(0);

  const finalHtml = buildPreviewHtml(html, css, js);
  const encoded = encodeHtmlToBase64(finalHtml);
  const source = { uri: `data:text/html;base64,${encoded}` };

  const handleRefresh = useCallback(() => {
    setJsError(null);
    setKey((k) => k + 1);
  }, []);

  const handleMessage = useCallback(
    (event: { nativeEvent: { data: string } }) => {
      try {
        const msg = JSON.parse(event.nativeEvent.data) as {
          type: string;
          message?: string;
          line?: number;
        };
        if (msg.type === 'error') {
          setJsError(
            msg.line
              ? `JS Error (line ${msg.line}): ${msg.message}`
              : `JS Error: ${msg.message}`
          );
        }
      } catch {
        // Non-JSON message, ignore
      }
    },
    []
  );

  const hasContent = html || css || js;

  if (!hasContent) {
    return (
      <View style={[styles.empty, { backgroundColor: '#ffffff' }]}>
        <Text style={styles.emptyIcon}>🌐</Text>
        <Text style={styles.emptyText}>Nothing to preview yet</Text>
        <Text style={styles.emptyHint}>
          Edit an HTML, CSS, or JS file to see live preview
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Preview header */}
      <View
        style={[
          styles.header,
          { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: theme.colors.muted }]}>PREVIEW</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity
            onPress={onToggleAutoRefresh}
            style={[
              styles.autoRefreshBtn,
              autoRefresh && { backgroundColor: theme.colors.overlay },
            ]}
          >
            <Text style={[styles.autoRefreshText, { color: autoRefresh ? theme.colors.accent : theme.colors.muted }]}>
              {autoRefresh ? '🔄 Auto' : '⏸ Manual'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleRefresh} style={styles.refreshBtn}>
            <Text style={[styles.refreshIcon, { color: theme.colors.text }]}>↻</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* JS Error Banner */}
      {jsError && (
        <View style={[styles.errorBanner, { backgroundColor: '#2b0d0d' }]}>
          <Text style={[styles.errorText, { color: theme.colors.error }]} numberOfLines={2}>
            ⚠ {jsError}
          </Text>
          <TouchableOpacity onPress={() => setJsError(null)}>
            <Text style={[styles.dismissError, { color: theme.colors.muted }]}>✕</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* WebView */}
      <WebView
        key={key}
        ref={webviewRef}
        source={source}
        style={styles.webview}
        javaScriptEnabled
        domStorageEnabled
        allowFileAccess
        originWhitelist={['*']}
        onLoadStart={() => setIsLoading(true)}
        onLoadEnd={() => setIsLoading(false)}
        onMessage={handleMessage}
        onNavigationStateChange={(event) => {
          // Block navigation away from data URI
          if (event.url && !event.url.startsWith('data:')) {
            webviewRef.current?.stopLoading();
          }
        }}
      />

      {isLoading && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator color={theme.colors.accent} size="small" />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  emptyIcon: { fontSize: 40, marginBottom: 12 },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#555',
    marginBottom: 4,
  },
  emptyHint: { fontSize: 13, color: '#888', textAlign: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.5,
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  autoRefreshBtn: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  autoRefreshText: { fontSize: 11, fontWeight: '600' },
  refreshBtn: { padding: 4 },
  refreshIcon: { fontSize: 18 },
  errorBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    gap: 8,
  },
  errorText: { flex: 1, fontSize: 11, fontFamily: 'JetBrainsMono-Regular' },
  dismissError: { fontSize: 14 },
  webview: { flex: 1 },
  loadingOverlay: {
    position: 'absolute',
    top: 40,
    right: 12,
  },
});
