import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { ExecutionResult } from '../../services/pistonService';
import { useTheme } from '../../hooks/useTheme';
import LoadingSpinner from '../common/LoadingSpinner';

interface OutputPanelProps {
  results: ExecutionResult[];
  isRunning: boolean;
  onRun: () => void;
  onClear: () => void;
  canRun: boolean;
}

export default function OutputPanel({
  results,
  isRunning,
  onRun,
  onClear,
  canRun,
}: OutputPanelProps) {
  const theme = useTheme();
  const latest = results[0] ?? null;

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.terminal },
      ]}
    >
      {/* Panel header */}
      <View
        style={[
          styles.header,
          { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: theme.colors.muted }]}>
          TERMINAL
        </Text>
        <View style={styles.headerActions}>
          {results.length > 0 && (
            <TouchableOpacity onPress={onClear} style={styles.actionBtn}>
              <Text style={[styles.actionText, { color: theme.colors.muted }]}>
                Clear
              </Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            onPress={onRun}
            disabled={!canRun || isRunning}
            style={[
              styles.runButton,
              { opacity: (!canRun || isRunning) ? 0.4 : 1 },
            ]}
          >
            <Text style={styles.runButtonText}>
              {isRunning ? '⏳' : '▶ Run'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Output content */}
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {isRunning && (
          <View style={styles.loadingContainer}>
            <LoadingSpinner size="small" label="Executing..." />
          </View>
        )}

        {!isRunning && !latest && (
          <Text style={[styles.placeholder, { color: theme.colors.muted }]}>
            Press ▶ Run to execute your code
          </Text>
        )}

        {!isRunning && latest && (
          <ResultBlock result={latest} theme={theme} />
        )}

        {results.slice(1).map((result, idx) => (
          <View key={idx} style={styles.historicalResult}>
            <View style={[styles.histDivider, { borderColor: theme.colors.border }]} />
            <Text style={[styles.histLabel, { color: theme.colors.muted }]}>
              Previous run — {result.timestamp}
            </Text>
            <ResultBlock result={result} theme={theme} compact />
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

interface ResultBlockProps {
  result: ExecutionResult;
  theme: ReturnType<typeof useTheme>;
  compact?: boolean;
}

function ResultBlock({ result, theme, compact }: ResultBlockProps) {
  const exitOk = result.exitCode === 0;
  const isTimeout = result.error === 'TIMEOUT';
  const isPreviewOnly = result.error === 'PREVIEW_ONLY';

  return (
    <View style={styles.resultBlock}>
      {/* Header row */}
      <View style={styles.resultHeader}>
        <Text style={[styles.timestamp, { color: theme.colors.muted }]}>
          [{result.timestamp}]
        </Text>
        {result.duration !== undefined && (
          <Text style={[styles.duration, { color: theme.colors.muted }]}>
            {result.duration}ms
          </Text>
        )}
        {result.exitCode !== null && result.exitCode !== undefined && (
          <View
            style={[
              styles.exitBadge,
              { backgroundColor: exitOk ? '#0d2b0d' : '#2b0d0d' },
            ]}
          >
            <Text
              style={[
                styles.exitBadgeText,
                { color: exitOk ? theme.colors.success : theme.colors.error },
              ]}
            >
              exit: {result.exitCode}
            </Text>
          </View>
        )}
      </View>

      {/* Compile error */}
      {result.compileStderr && result.compileExitCode !== 0 && (
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: '#d29922' }]}>
            COMPILATION FAILED
          </Text>
          <Text
            style={[
              styles.outputText,
              { color: theme.colors.warning, fontFamily: 'JetBrainsMono-Regular' },
            ]}
          >
            {result.compileStderr}
          </Text>
        </View>
      )}

      {/* stdout */}
      {result.stdout ? (
        <Text
          style={[
            styles.outputText,
            {
              color: theme.colors.text,
              fontFamily: 'JetBrainsMono-Regular',
              fontSize: compact ? 11 : 12,
            },
          ]}
        >
          {result.stdout}
        </Text>
      ) : null}

      {/* stderr */}
      {result.stderr ? (
        <Text
          style={[
            styles.outputText,
            {
              color: isTimeout || isPreviewOnly ? theme.colors.warning : theme.colors.error,
              fontFamily: 'JetBrainsMono-Regular',
              fontSize: compact ? 11 : 12,
            },
          ]}
        >
          {result.stderr}
        </Text>
      ) : null}

      {/* Signal */}
      {result.signal && (
        <Text style={[styles.signal, { color: theme.colors.error }]}>
          Signal: {result.signal}
        </Text>
      )}

      {/* Empty output */}
      {!result.stdout && !result.stderr && !result.error && (
        <Text style={[styles.emptyOutput, { color: theme.colors.muted }]}>
          (no output)
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.5,
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  actionBtn: {
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  actionText: {
    fontSize: 12,
  },
  runButton: {
    backgroundColor: '#0d2b1a',
    paddingHorizontal: 14,
    paddingVertical: 5,
    borderRadius: 6,
  },
  runButtonText: {
    color: '#3fb950',
    fontSize: 12,
    fontWeight: '600',
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    padding: 12,
    flexGrow: 1,
  },
  loadingContainer: {
    alignItems: 'flex-start',
    paddingVertical: 8,
  },
  placeholder: {
    fontSize: 12,
    fontFamily: 'JetBrainsMono-Regular',
    opacity: 0.5,
  },
  resultBlock: {
    gap: 4,
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  timestamp: {
    fontSize: 10,
    fontFamily: 'JetBrainsMono-Regular',
  },
  duration: {
    fontSize: 10,
  },
  exitBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  exitBadgeText: {
    fontSize: 10,
    fontWeight: '600',
  },
  section: {
    gap: 2,
  },
  sectionLabel: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.8,
  },
  outputText: {
    lineHeight: 18,
  },
  signal: {
    fontSize: 11,
    fontFamily: 'JetBrainsMono-Regular',
  },
  emptyOutput: {
    fontSize: 11,
    fontStyle: 'italic',
  },
  historicalResult: {
    marginTop: 12,
    opacity: 0.5,
  },
  histDivider: {
    borderTopWidth: StyleSheet.hairlineWidth,
    marginBottom: 6,
  },
  histLabel: {
    fontSize: 10,
    marginBottom: 4,
  },
});
