import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useTheme } from '../../hooks/useTheme';

export type PanelMode = 'terminal' | 'preview';

interface PanelToggleProps {
  mode: PanelMode;
  onModeChange: (mode: PanelMode) => void;
  canPreview: boolean;
}

export default function PanelToggle({ mode, onModeChange, canPreview }: PanelToggleProps) {
  const theme = useTheme();

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.surface, borderBottomColor: theme.colors.border },
      ]}
    >
      <TouchableOpacity
        onPress={() => onModeChange('terminal')}
        style={[
          styles.tab,
          mode === 'terminal' && { borderBottomColor: theme.colors.accent },
        ]}
      >
        <Text
          style={[
            styles.tabText,
            { color: mode === 'terminal' ? theme.colors.text : theme.colors.muted },
          ]}
        >
          Terminal
        </Text>
      </TouchableOpacity>

      {canPreview && (
        <TouchableOpacity
          onPress={() => onModeChange('preview')}
          style={[
            styles.tab,
            mode === 'preview' && { borderBottomColor: theme.colors.accent },
          ]}
        >
          <Text
            style={[
              styles.tabText,
              { color: mode === 'preview' ? theme.colors.text : theme.colors.muted },
            ]}
          >
            Preview
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    borderBottomWidth: 1,
  },
  tab: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabText: {
    fontSize: 12,
    fontWeight: '600',
  },
});
