import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import { ALL_THEMES } from '../../themes/themeRegistry';
import { useSettingsStore } from '../../store/settingsStore';

const PREVIEW_CODE = `function hello() {
  const msg = "AS Code";
  return msg;
}`;

export default function ThemePicker() {
  const { activeTheme, setActiveTheme } = useSettingsStore();

  return (
    <FlatList
      data={ALL_THEMES}
      keyExtractor={(item) => item.id}
      numColumns={2}
      columnWrapperStyle={styles.row}
      contentContainerStyle={styles.content}
      renderItem={({ item }) => {
        const isActive = item.id === activeTheme;
        return (
          <TouchableOpacity
            onPress={() => setActiveTheme(item.id)}
            style={[
              styles.card,
              { backgroundColor: item.colors.surface, borderColor: item.colors.border },
              isActive && { borderColor: item.colors.accent, borderWidth: 2 },
            ]}
            activeOpacity={0.75}
          >
            {/* Mini code preview */}
            <View
              style={[
                styles.codePreview,
                { backgroundColor: item.colors.background },
              ]}
            >
              <Text
                style={[
                  styles.previewText,
                  { color: item.syntax.keyword },
                ]}
              >
                {'function '}
                <Text style={{ color: item.syntax.function }}>{'hello'}</Text>
                <Text style={{ color: item.syntax.punctuation }}>{'() {'}</Text>
              </Text>
              <Text
                style={[styles.previewText, { color: item.syntax.plain }]}
              >
                {'  '}
                <Text style={{ color: item.syntax.keyword }}>{'const '}</Text>
                <Text style={{ color: item.syntax.variable }}>{'msg'}</Text>
                <Text style={{ color: item.syntax.operator }}>{' = '}</Text>
                <Text style={{ color: item.syntax.string }}>
                  {'"AS Code"'}
                </Text>
              </Text>
              <Text
                style={[styles.previewText, { color: item.syntax.comment }]}
              >
                {'  // comment'}
              </Text>
            </View>

            {/* Theme name + active badge */}
            <View style={styles.footer}>
              <Text
                style={[styles.themeName, { color: item.colors.text }]}
                numberOfLines={1}
              >
                {item.name}
              </Text>
              {isActive && (
                <View
                  style={[
                    styles.activeBadge,
                    { backgroundColor: item.colors.accent + '22' },
                  ]}
                >
                  <Text style={[styles.activeBadgeText, { color: item.colors.accent }]}>
                    ✓
                  </Text>
                </View>
              )}
            </View>
          </TouchableOpacity>
        );
      }}
    />
  );
}

const styles = StyleSheet.create({
  content: { padding: 12, gap: 10 },
  row: { gap: 10 },
  card: {
    flex: 1,
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
  },
  codePreview: {
    padding: 10,
    minHeight: 80,
  },
  previewText: {
    fontSize: 10,
    fontFamily: 'JetBrainsMono-Regular',
    lineHeight: 16,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    gap: 6,
  },
  themeName: {
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  activeBadge: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeBadgeText: {
    fontSize: 11,
    fontWeight: '700',
  },
});
