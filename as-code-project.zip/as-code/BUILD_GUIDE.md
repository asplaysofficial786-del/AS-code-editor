# AS Code — Complete Build Guide
## How to Turn This Code Into an Android APK

---

## STEP 0 — Prerequisites (install these first)

| Tool | Version | Download |
|------|---------|----------|
| Node.js | 20 LTS | https://nodejs.org |
| Java JDK | 17 | https://adoptium.net |
| Git | any | https://git-scm.com |
| Expo CLI | latest | via npm (below) |
| EAS CLI | latest | via npm (below) |

```bash
# Install Expo + EAS CLIs globally
npm install -g expo-cli eas-cli

# Verify Java
java -version   # should say 17.x

# Create a FREE Expo account at https://expo.dev
eas login       # log in from terminal
```

---

## STEP 1 — Set Up the Project

```bash
# 1. Place the entire as-code/ folder somewhere on your computer

# 2. Install all dependencies
cd as-code
npm install

# 3. Copy .env.example → .env and add your Claude API key
cp .env.example .env
# Open .env and paste your key:
# EXPO_PUBLIC_CLAUDE_API_KEY=sk-ant-xxxxxxxxxxxxxxxx
# Get your key at: https://console.anthropic.com
```

---

## STEP 2 — Add the JetBrains Mono Font

Download the font and place it at:
```
as-code/assets/fonts/JetBrainsMono-Regular.ttf
```

Download from: https://www.jetbrains.com/lp/mono/
(free, open source font)

---

## STEP 3 — Add a Placeholder App Icon

Place any 1024×1024 PNG at:
```
as-code/assets/icons/app-icon.png
```

You can use any image for development. For production, design a proper icon.

---

## STEP 4 — Configure EAS Build

```bash
# This creates/updates eas.json with your Expo project ID
eas build:configure
```

When prompted:
- Platform: **Android**
- It will link to your Expo account and generate a project ID
- Open `app.json` and replace `"your-eas-project-id-here"` with the generated ID

---

## STEP 5 — Build the APK

### Option A — Cloud Build (Recommended, no Android Studio needed)

```bash
# Build a debug APK (fastest, for testing)
eas build --platform android --profile preview

# This uploads your code to Expo's servers and builds in the cloud
# Takes ~10–15 minutes
# When done, you get a download link for the .apk file
```

### Option B — Local Build (requires Android Studio)

```bash
# Install Android Studio from https://developer.android.com/studio
# In Android Studio: SDK Manager → Install Android SDK 34

# Set environment variables:
export ANDROID_HOME=$HOME/Library/Android/sdk   # macOS
export ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk  # Windows

# Generate native Android project
npx expo run:android

# Or build release APK locally:
eas build --platform android --profile preview --local
```

---

## STEP 6 — Install on Your Android Phone

### Method 1 — Download from EAS (easiest)
1. After build finishes, EAS gives you a QR code + download link
2. Open the link on your phone
3. Tap the `.apk` file to download
4. Go to **Settings → Security → Install Unknown Apps** → enable for your browser
5. Tap the downloaded APK to install

### Method 2 — ADB (USB cable)
```bash
# Enable Developer Mode on your phone:
# Settings → About Phone → tap Build Number 7 times
# Settings → Developer Options → USB Debugging ON

# Connect phone via USB, then:
adb devices           # verify phone is detected
adb install as-code.apk
```

### Method 3 — File Transfer
1. Build APK using Option A above
2. Download the APK to your computer
3. Copy it to your phone via USB / Google Drive / email
4. Open it on your phone to install

---

## STEP 7 — Run in Development Mode (live reload)

```bash
# Start Expo dev server
npx expo start

# On your phone:
# 1. Install "Expo Go" from Play Store
# 2. Scan the QR code shown in terminal
# 3. App loads instantly with hot reload
```

> **Note:** Expo Go has some limitations. For full native features (SecureStore, File System), use a development build:
```bash
eas build --platform android --profile development
```

---

## STEP 8 — Production AAB (for Google Play Store)

```bash
# Build Android App Bundle (required for Play Store)
eas build --platform android --profile production

# This creates a .aab file
# Upload it to Google Play Console at https://play.google.com/console
```

---

## Troubleshooting

### "Invariant Violation: requireNativeComponent" error
```bash
npx expo prebuild --clean
npx expo run:android
```

### Metro bundler stuck
```bash
npx expo start --clear
```

### EAS build fails — Java version
```bash
# Make sure JAVA_HOME points to JDK 17
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk   # Linux
export JAVA_HOME=$(/usr/libexec/java_home -v 17) # macOS
```

### "No module found" errors
```bash
rm -rf node_modules
npm install
npx expo install  # re-links Expo-specific packages
```

### AsyncStorage not found
```bash
npx expo install @react-native-async-storage/async-storage
```

---

## Project Structure Quick Reference

```
as-code/
├── App.tsx                    ← Entry point, loads fonts
├── app.json                   ← Expo config (name, bundle ID, icons)
├── eas.json                   ← EAS build profiles
├── .env                       ← Your API keys (gitignored)
├── src/
│   ├── config/
│   │   ├── apiKeys.ts         ← Claude API config
│   │   └── pistonConfig.ts    ← Piston language map
│   ├── screens/
│   │   ├── EditorScreen.tsx   ← Main editor (Tab 1)
│   │   ├── ExplorerScreen.tsx ← File tree (Tab 2)
│   │   ├── ExtensionsScreen.tsx ← Themes/plugins (Tab 3)
│   │   ├── DocsScreen.tsx     ← Offline docs (Tab 4)
│   │   ├── SettingsScreen.tsx ← Preferences (Tab 5)
│   │   ├── GitScreen.tsx      ← Git integration
│   │   ├── SnippetsScreen.tsx ← Snippet library
│   │   └── AboutScreen.tsx    ← App info + AS Lang note
│   ├── services/
│   │   ├── claudeService.ts   ← Claude AI streaming
│   │   └── pistonService.ts   ← Code execution
│   ├── store/                 ← Zustand state management
│   └── themes/                ← 10 color themes
└── assets/
    ├── fonts/JetBrainsMono-Regular.ttf
    └── icons/app-icon.png
```

---

## API Keys Summary

| Service | Required | Where to Get | Where to Add |
|---------|----------|--------------|--------------|
| Claude API | Yes (for AI) | console.anthropic.com | `.env` → `EXPO_PUBLIC_CLAUDE_API_KEY` |
| Piston API | No (it's free) | emkc.org (no key needed) | Already configured |
| GitHub PAT | Optional (for Git) | github.com/settings/tokens | In-app Git screen |

---

## Build Profiles Summary

| Profile | Command | Output | Use For |
|---------|---------|--------|---------|
| `preview` | `eas build --profile preview` | `.apk` | Testing on device |
| `development` | `eas build --profile development` | `.apk` + dev client | Development with full native APIs |
| `production` | `eas build --profile production` | `.aab` | Play Store submission |

---

*AS Code — Built with React Native, Expo, and Claude AI*
