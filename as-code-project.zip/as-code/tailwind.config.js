/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./App.{js,jsx,ts,tsx}', './src/**/*.{js,jsx,ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        // GitHub Dark Pro palette
        'gh-base': '#0d1117',
        'gh-surface': '#161b22',
        'gh-overlay': '#21262d',
        'gh-border': '#30363d',
        'gh-accent': '#58a6ff',
        'gh-success': '#3fb950',
        'gh-error': '#f85149',
        'gh-warning': '#d29922',
        'gh-text': '#c9d1d9',
        'gh-muted': '#8b949e',
        'gh-terminal': '#010409',
        // AI gradient
        'ai-purple': '#7c3aed',
        'ai-blue': '#2563eb',
      },
      fontFamily: {
        mono: ['JetBrainsMono-Regular'],
      },
    },
  },
  plugins: [],
};
